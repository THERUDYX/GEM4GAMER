
import React from 'react';
import { HashRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { DataProvider } from './contexts/DataContext';
import { useAuth } from './hooks/useAuth';

import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import LoadingSpinner from './components/ui/LoadingSpinner';

// Pages
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import UserDashboardPage from './pages/UserDashboardPage';
import UserProfilePage from './pages/UserProfilePage';

// Admin Pages
import AdminDashboardPage from './pages/admin/AdminDashboardPage';
import AdminTournamentsPage from './pages/admin/AdminTournamentsPage';
import AdminTransactionsPage from './pages/admin/AdminTransactionsPage';
import AdminBankDetailsPage from './pages/admin/AdminBankDetailsPage';
import AdminUsersPage from './pages/admin/AdminUsersPage';

// Owner Pages
import OwnerDashboardPage from './pages/owner/OwnerDashboardPage'; // New
import OwnerUsersPage from './pages/owner/OwnerUsersPage'; // New

import NotFoundPage from './pages/NotFoundPage';

import { 
  ROUTE_HOME, ROUTE_LOGIN, ROUTE_SIGNUP, ROUTE_PROFILE, 
  ROUTE_ADMIN_DASHBOARD, ROUTE_ADMIN_TOURNAMENTS, ROUTE_ADMIN_TRANSACTIONS, ROUTE_ADMIN_BANK_DETAILS, ROUTE_ADMIN_USERS,
  ROUTE_OWNER_DASHBOARD, ROUTE_OWNER_USERS // New
} from './constants';

interface ProtectedRouteProps {
  adminOnly?: boolean;
  ownerOnly?: boolean;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ adminOnly = false, ownerOnly = false }) => {
  const { currentUser, isAdmin, isOwner, loading } = useAuth();

  if (loading) {
    return <div className="flex justify-center items-center h-screen"><LoadingSpinner text="Authenticating..." /></div>;
  }

  if (!currentUser) {
    return <Navigate to={ROUTE_LOGIN} replace />;
  }

  if (ownerOnly && !isOwner) {
    // If ownerOnly is true, but user is not owner, redirect. Admins are not implicitly owners.
    return <Navigate to={ROUTE_HOME} replace />; 
  }

  if (adminOnly && !isAdmin && !isOwner) {
    // If adminOnly is true, but user is neither admin nor owner, redirect.
    // Owners have admin privileges for this check.
    return <Navigate to={ROUTE_HOME} replace />; 
  }


  return <Outlet />; 
};


const AppContent: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background-DEFAULT text-neutral-light">
      <Navbar />
      <main className="flex-grow">
        <Routes>
          {/* Public Routes */}
          <Route path={ROUTE_LOGIN} element={<LoginPage />} />
          <Route path={ROUTE_SIGNUP} element={<SignupPage />} />

          {/* User Protected Routes (accessible by any logged-in user) */}
          <Route element={<ProtectedRoute />}>
            <Route path={ROUTE_HOME} element={<UserDashboardPage />} />
            <Route path={ROUTE_PROFILE} element={<UserProfilePage />} />
          </Route>

          {/* Admin Protected Routes (accessible by admin and owner) */}
          <Route element={<ProtectedRoute adminOnly={true} />}>
            <Route path={ROUTE_ADMIN_DASHBOARD} element={<AdminDashboardPage />} />
            <Route path={ROUTE_ADMIN_TOURNAMENTS} element={<AdminTournamentsPage />} />
            <Route path={ROUTE_ADMIN_TRANSACTIONS} element={<AdminTransactionsPage />} />
            <Route path={ROUTE_ADMIN_BANK_DETAILS} element={<AdminBankDetailsPage />} />
            <Route path={ROUTE_ADMIN_USERS} element={<AdminUsersPage />} />
          </Route>

          {/* Owner Protected Routes (accessible ONLY by owner) */}
          <Route element={<ProtectedRoute ownerOnly={true} />}>
            <Route path={ROUTE_OWNER_DASHBOARD} element={<OwnerDashboardPage />} />
            <Route path={ROUTE_OWNER_USERS} element={<OwnerUsersPage />} />
          </Route>
          
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <AuthProvider>
        <DataProvider> 
            <AppContent />
        </DataProvider>
      </AuthProvider>
    </HashRouter>
  );
};

export default App;