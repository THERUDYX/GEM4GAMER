

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage
import Input from '../ui/Input';
import Button from '../ui/Button';
import { ROUTE_SIGNUP, ROUTE_HOME, ROUTE_ADMIN_DASHBOARD } from '../../constants';
import { AlertMessage } from '../../types';
import Alert from '../ui/Alert'; 
import LoadingSpinner from '../ui/LoadingSpinner';

const AppLogoMini: React.FC = () => (
  <svg width="60" height="60" viewBox="0 0 150 150" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-secondary mx-auto mb-2">
    <circle cx="75" cy="75" r="65" stroke="currentColor" strokeWidth="10"/>
    <path d="M50 50 L75 75 L100 50 M75 75 L75 110" stroke="#FFC107" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round"/>
     <path d="M75 35 Q 95 45, 105 65" stroke="currentColor" strokeWidth="8" fill="none" />
    <path d="M75 35 Q 55 45, 45 65" stroke="currentColor" strokeWidth="8" fill="none" />
  </svg>
);


const LoginForm: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login, loading: authLoading } = useAuth();
  // const { t, translationsLoading } = useLanguage(); // Removed useLanguage
  const navigate = useNavigate();
  const [alert, setAlert] = useState<AlertMessage | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlert(null);
    try {
      const user = await login(email, password);
      if (user) {
        setAlert({ id: 'loginSuccess', type: 'success', message: "Login successful! Redirecting..." });
        setTimeout(() => {
          if (user.role === 'admin') {
            navigate(ROUTE_ADMIN_DASHBOARD);
          } else {
            navigate(ROUTE_HOME);
          }
        }, 1200);
      } else {
        setAlert({ id: 'loginError', type: 'error', message: "Invalid email or password. Please try again." });
      }
    } catch (err) { 
        setAlert({ id: 'loginErrorCatch', type: 'error', message: "An unexpected error occurred during login." });
    }
  };

  const isLoading = authLoading; // Removed translationsLoading

  // if (translationsLoading && !email) { // Removed translationsLoading check
  //     return (
  //       <div className="min-h-screen flex items-center justify-center bg-background-DEFAULT">
  //           <LoadingSpinner text={"Loading..."} />
  //       </div>
  //     )
  // }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background-DEFAULT py-12 px-4 sm:px-6 lg:px-8">
      {alert && <Alert alert={alert} onDismiss={() => setAlert(null)} />}
      <div className="max-w-md w-full space-y-10 p-8 sm:p-10 bg-background-paper shadow-2xl rounded-xl border-t-4 border-secondary">
        <div className="text-center">
          <AppLogoMini />
          <h2 className="mt-4 text-center text-3xl font-extrabold text-neutral-light">
            Welcome Back!
          </h2>
          <p className="mt-2 text-center text-sm text-neutral-default">
            Sign in to access your esports hub.
          </p>
        </div>
        <form className="space-y-6" onSubmit={handleSubmit}>
          <Input
            label="Email address"
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            Icon={() => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" /></svg>}
          />
          <Input
            label="Password"
            id="password"
            name="password"
            type="password"
            autoComplete="current-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
             Icon={() => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" /></svg>}
          />

          <div className="flex items-center justify-between text-sm">
            <a 
              href="https://wa.me/916203929125" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="font-medium text-accent hover:text-accent-light transition-colors duration-200"
            >
              Forgot Password?
            </a>
            <Link to={ROUTE_SIGNUP} className="font-medium text-accent hover:text-accent-light transition-colors duration-200">
              Don't have an account? Sign up
            </Link>
          </div>

          <div>
            <Button type="submit" className="w-full" isLoading={isLoading} variant="primary" size="lg">
              Sign in
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoginForm;