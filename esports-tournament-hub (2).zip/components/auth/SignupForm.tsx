

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage
import Input from '../ui/Input';
import Button from '../ui/Button';
import { ROUTE_LOGIN, ROUTE_HOME } from '../../constants';
import { isValidEmail, isValidPassword } from '../../utils/helpers';
import { AlertMessage } from '../../types';
import Alert from '../ui/Alert';
import LoadingSpinner from '../ui/LoadingSpinner';

const AppLogoMini: React.FC = () => (
  <svg width="60" height="60" viewBox="0 0 150 150" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-secondary mx-auto mb-2">
    <circle cx="75" cy="75" r="65" stroke="currentColor" strokeWidth="10"/>
    <path d="M50 50 L75 75 L100 50 M75 75 L75 110" stroke="#FFC107" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round"/>
     <path d="M75 35 Q 95 45, 105 65" stroke="currentColor" strokeWidth="8" fill="none" />
    <path d="M75 35 Q 55 45, 45 65" stroke="currentColor" strokeWidth="8" fill="none" />
  </svg>
);

const SignupForm: React.FC = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [mobileNumber, setMobileNumber] = useState(''); // Added mobileNumber state
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const { signup, loading: authLoading } = useAuth();
  // const { t, translationsLoading } = useLanguage(); // Removed useLanguage
  const navigate = useNavigate();
  const [alert, setAlert] = useState<AlertMessage | null>(null);
  const [errors, setErrors] = useState<{ username?: string; email?: string; mobileNumber?: string; password?: string; confirmPassword?: string }>({}); // Added mobileNumber to errors

  const validateForm = (): boolean => {
    const newErrors: { username?: string; email?: string; mobileNumber?: string; password?: string; confirmPassword?: string } = {};
    if (!username || username.trim().length < 3) {
      newErrors.username = "Username must be at least 3 characters long.";
    } else if (username.includes(" ")) {
      newErrors.username = "Username cannot contain spaces.";
    }
    if (!isValidEmail(email)) {
      newErrors.email = "Please enter a valid email address.";
    }
    if (!mobileNumber.trim()) {
        newErrors.mobileNumber = "Mobile number is required.";
    } else if (!/^\d{10}$/.test(mobileNumber.trim())) { // Basic 10-digit validation
        newErrors.mobileNumber = "Mobile number must be 10 digits.";
    }
    if (!isValidPassword(password)) {
      newErrors.password = "Password must be at least 6 characters long.";
    }
    if (password !== confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlert(null);
    if (!validateForm()) {
      return;
    }
    try {
      const user = await signup(username.trim(), email.trim(), mobileNumber.trim(), password); // Pass mobileNumber to signup
      if (user) {
        setAlert({ id: 'signupSuccess', type: 'success', message: "Signup successful! Welcome aboard. Redirecting..." });
        setTimeout(() => navigate(ROUTE_HOME), 1500);
      } else {
        setAlert({ id: 'signupError', type: 'error', message: "Signup failed. Please try again." });
      }
    } catch (error: any) {
       setAlert({ id: 'signupErrorCatch', type: 'error', message: error.message || "An unexpected error occurred during signup." });
    }
  };

  const isLoading = authLoading; // Removed translationsLoading

  // if (translationsLoading && !username) { // Removed translationsLoading check
  //     return (
  //       <div className="min-h-screen flex items-center justify-center bg-background-DEFAULT">
  //           <LoadingSpinner text={"Loading..."} />
  //       </div>
  //     )
  // }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background-DEFAULT py-12 px-4 sm:px-6 lg:px-8">
      {alert && <Alert alert={alert} onDismiss={() => setAlert(null)} />}
      <div className="max-w-md w-full space-y-8 p-8 sm:p-10 bg-background-paper shadow-2xl rounded-xl border-t-4 border-secondary">
        <div className="text-center">
          <AppLogoMini />
          <h2 className="mt-4 text-center text-3xl font-extrabold text-neutral-light">
            Join the Arena
          </h2>
           <p className="mt-2 text-center text-sm text-neutral-default">
            Create your account to start competing.
          </p>
        </div>
        <form className="space-y-5" onSubmit={handleSubmit}>
          <Input
            label="Username"
            id="username-signup"
            name="username"
            type="text"
            autoComplete="username"
            required
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            error={errors.username}
            placeholder="Choose your gaming handle"
            Icon={() => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" /></svg>}
          />
          <Input
            label="Email address"
            id="email-signup"
            name="email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            error={errors.email}
            placeholder="you@example.com"
            Icon={() => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" /></svg>}
          />
           <Input
            label="Mobile Number (10 digits)"
            id="mobileNumber-signup"
            name="mobileNumber"
            type="tel" 
            autoComplete="tel"
            required
            value={mobileNumber}
            onChange={(e) => setMobileNumber(e.target.value)}
            error={errors.mobileNumber}
            placeholder="9876543210"
            Icon={() => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M10.5 1.5H8.25A2.25 2.25 0 006 3.75v16.5a2.25 2.25 0 002.25 2.25h7.5A2.25 2.25 0 0018 20.25V3.75a2.25 2.25 0 00-2.25-2.25H13.5m-3 0V3h3V1.5m-3 0h3m-3 18h3m-3-9h3m-3-3h3m-3-3h3M6.75 6H6m.75 3H6m.75 3H6m.75 3H6m.75 3H6" /></svg>}
          />
          <Input
            label="Password"
            id="password-signup"
            name="password"
            type="password"
            autoComplete="new-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            error={errors.password}
            placeholder="•••••••• (min. 6 characters)"
            Icon={() => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" /></svg>}
          />
          <Input
            label="Confirm Password"
            id="confirm-password-signup"
            name="confirmPassword"
            type="password"
            autoComplete="new-password"
            required
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            error={errors.confirmPassword}
            placeholder="••••••••"
             Icon={() => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
          />
          <div className="pt-1">
            <Button type="submit" className="w-full" isLoading={isLoading} variant="primary" size="lg">
              Create Account
            </Button>
          </div>
          <div className="text-sm text-center">
            <Link to={ROUTE_LOGIN} className="font-medium text-accent hover:text-accent-light transition-colors duration-200">
              Already have an account? Sign in
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SignupForm;