

import React from 'react';
import { APP_NAME } from '../../constants';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage

const Footer: React.FC = () => {
  // const { t } = useLanguage(); // Removed useLanguage
  return (
    <footer className="bg-primary-dark text-neutral-dark mt-auto">
      <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8 text-center">
        <p className="text-sm">
          &copy; {new Date().getFullYear()} {APP_NAME}. All rights reserved.
        </p>
        <p className="text-xs mt-1">
          This is a simulated application. Do not use real financial information.
        </p>
      </div>
    </footer>
  );
};

export default Footer;