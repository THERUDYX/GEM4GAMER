
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import Button from '../ui/Button';
import { ROUTE_HOME, ROUTE_LOGIN, ROUTE_PROFILE, ROUTE_ADMIN_DASHBOARD, ROUTE_OWNER_DASHBOARD, CURRENCY_SYMBOL, APP_NAME } from '../../constants';
import { formatCurrency } from '../../utils/helpers';

const AppLogo: React.FC = () => (
  <svg width="40" height="40" viewBox="0 0 150 150" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-secondary">
    <circle cx="75" cy="75" r="65" stroke="currentColor" strokeWidth="12"/>
    <path d="M50 50 L75 75 L100 50 M75 75 L75 110" stroke="#FFC107" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M75 35 Q 95 45, 105 65" stroke="currentColor" strokeWidth="8" fill="none" />
    <path d="M75 35 Q 55 45, 45 65" stroke="currentColor" strokeWidth="8" fill="none" />
  </svg>
);


const Navbar: React.FC = () => {
  const { currentUser, isAdmin, isOwner, logout } = useAuth(); // Added isOwner
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate(ROUTE_LOGIN);
  };

  const navLinkClasses = "text-neutral-default hover:text-secondary px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200";

  return (
    <nav className="bg-primary-dark shadow-xl sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <Link to={ROUTE_HOME} className="flex-shrink-0 flex items-center space-x-2">
              <AppLogo />
               <span className="text-secondary text-xl font-bold tracking-tight">{APP_NAME}</span>
            </Link>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-1">
              {currentUser ? (
                <>
                  <span className="text-neutral-light px-3 py-2 rounded-md text-sm font-medium">
                    Hi, {currentUser.username || currentUser.email}
                  </span>
                  {isOwner ? ( // Owner check first
                    <Link
                      to={ROUTE_OWNER_DASHBOARD}
                      className={navLinkClasses}
                    >
                      Owner Panel
                    </Link>
                  ) : isAdmin ? (
                    <Link
                      to={ROUTE_ADMIN_DASHBOARD}
                      className={navLinkClasses}
                    >
                      Admin Panel
                    </Link>
                  ) : (
                    <Link
                      to={ROUTE_PROFILE}
                      className={navLinkClasses}
                    >
                      Profile
                    </Link>
                  )}
                   <Link
                     to={ROUTE_PROFILE}
                     className={navLinkClasses}
                     title="Profile"
                   >
                     Balance: {formatCurrency(currentUser.balance, CURRENCY_SYMBOL)}
                   </Link>
                  <Button onClick={handleLogout} variant="secondary" size="sm" className="ml-3">
                    Logout
                  </Button>
                </>
              ) : (
                <Link
                  to={ROUTE_LOGIN}
                  className={navLinkClasses}
                >
                  Login / Signup
                </Link>
              )}
            </div>
          </div>
          <div className="-mr-2 flex md:hidden items-center">
             {currentUser ? (
                <Button onClick={handleLogout} variant="secondary" size="sm">
                    Logout
                  </Button>
             ) : (
                <Link to={ROUTE_LOGIN}>
                  <Button variant="primary" size="sm">Login / Signup</Button>
                </Link>
             )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;