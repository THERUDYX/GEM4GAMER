import React, { ReactNode } from 'react';

interface PageContainerProps {
  children: ReactNode;
  title?: string;
}

const PageContainer: React.FC<PageContainerProps> = ({ children, title }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-12">
      {title && (
        <h1 className="text-3xl md:text-4xl font-bold text-secondary mb-8 tracking-tight text-shadow-sm">
          {title}
        </h1>
      )}
      {children}
    </div>
  );
};

export default PageContainer;