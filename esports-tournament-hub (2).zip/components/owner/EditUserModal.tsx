
import React, { useState, useEffect } from 'react';
import { User, AlertMessage } from '../../types';
import Modal from '../ui/Modal';
import Input from '../ui/Input';
import Button from '../ui/Button';
import { useData } from '../../hooks/useData';
import Alert from '../ui/Alert';
import { CURRENCY_SYMBOL } from '../../constants';
import { isValidEmail } from '../../utils/helpers';

interface EditUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  userToEdit: User | null;
}

const EditUserModal: React.FC<EditUserModalProps> = ({ isOpen, onClose, userToEdit }) => {
  const { ownerUpdateUser, isLoadingData, allUsers } = useData();
  const [formData, setFormData] = useState<Partial<User>>({});
  const [alertInfo, setAlertInfo] = useState<AlertMessage | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (userToEdit && isOpen) {
      setFormData({
        id: userToEdit.id,
        username: userToEdit.username,
        email: userToEdit.email,
        mobileNumber: userToEdit.mobileNumber || '',
        password: '', // Keep password blank initially for editing, or show current if needed (but that's less secure to prefill)
        role: userToEdit.role,
        balance: userToEdit.balance,
      });
      setAlertInfo(null);
      setErrors({});
    }
  }, [userToEdit, isOpen]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'balance' ? parseFloat(value) : value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    if (!formData.id?.trim()) newErrors.id = "User ID is required.";
    if (!formData.username?.trim()) newErrors.username = "Username is required.";
    if (formData.username && formData.username.includes(" ")) newErrors.username = "Username cannot contain spaces.";
    if (!formData.email?.trim() || !isValidEmail(formData.email)) newErrors.email = "Valid email is required.";
    if (!formData.mobileNumber?.trim() || !/^\d{10}$/.test(formData.mobileNumber)) newErrors.mobileNumber = "Valid 10-digit mobile number is required.";
    if (formData.password && formData.password.length < 6) newErrors.password = "New password must be at least 6 characters.";
    if (typeof formData.balance !== 'number' || isNaN(formData.balance) || formData.balance < 0) newErrors.balance = "Valid balance is required.";
    
    // Uniqueness checks (excluding the current user being edited if the value hasn't changed)
    if (formData.id && formData.id !== userToEdit?.id && allUsers.some(u => u.id === formData.id)) {
        newErrors.id = "This User ID is already taken by another user.";
    }
    if (formData.username && formData.username !== userToEdit?.username && allUsers.some(u => u.username.toLowerCase() === formData.username?.toLowerCase())) {
        newErrors.username = "This username is already taken by another user.";
    }
    if (formData.email && formData.email !== userToEdit?.email && allUsers.some(u => u.email.toLowerCase() === formData.email?.toLowerCase())) {
        newErrors.email = "This email is already taken by another user.";
    }
    if (formData.mobileNumber && formData.mobileNumber !== userToEdit?.mobileNumber && allUsers.some(u => u.mobileNumber === formData.mobileNumber)) {
        newErrors.mobileNumber = "This mobile number is already taken by another user.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlertInfo(null);

    if (!userToEdit || !validateForm()) {
      return;
    }

    const updates: Partial<User> = { ...formData };
    if (!updates.password?.trim()) { // If password field is empty, don't update it
      delete updates.password;
    }

    try {
      await ownerUpdateUser(userToEdit.id, updates);
      setAlertInfo({ id: 'userUpdateSuccess', type: 'success', message: `User '${userToEdit.username}' updated successfully.` });
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (error: any) {
      setAlertInfo({ id: 'userUpdateFail', type: 'error', message: error.message || "Failed to update user." });
    }
  };

  if (!userToEdit) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Edit User: ${userToEdit.username}`} size="lg">
      {alertInfo && <Alert alert={alertInfo} onDismiss={() => setAlertInfo(null)} />}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="p-3 bg-red-800/20 border border-red-700 rounded-md text-red-300 text-xs">
          <strong>Warning:</strong> Editing User ID is highly risky and can corrupt data. Proceed with extreme caution. Passwords will be updated directly if a new one is provided.
        </div>
        <Input label="User ID" name="id" value={formData.id || ''} onChange={handleInputChange} error={errors.id} required />
        <Input label="Username" name="username" value={formData.username || ''} onChange={handleInputChange} error={errors.username} required />
        <Input label="Email" name="email" type="email" value={formData.email || ''} onChange={handleInputChange} error={errors.email} required />
        <Input label="Mobile Number" name="mobileNumber" type="tel" value={formData.mobileNumber || ''} onChange={handleInputChange} error={errors.mobileNumber} required />
        <Input label="New Password (leave blank to keep current)" name="password" type="text" value={formData.password || ''} onChange={handleInputChange} error={errors.password} placeholder="Enter new password to change" />
        
        <div>
          <label htmlFor="role" className="block text-sm font-medium text-neutral-light mb-1.5">Role</label>
          <select
            id="role"
            name="role"
            value={formData.role || 'user'}
            onChange={handleInputChange}
            className="block w-full px-3 py-2.5 border rounded-lg shadow-sm bg-primary-light border-primary-dark text-neutral-light focus:outline-none focus:ring-2 focus:ring-secondary focus:border-secondary sm:text-sm"
          >
            <option value="user">User</option>
            <option value="admin">Admin</option>
            <option value="owner">Owner</option>
          </select>
        </div>
        
        <Input label={`Balance (${CURRENCY_SYMBOL})`} name="balance" type="number" value={String(formData.balance || 0)} onChange={handleInputChange} error={errors.balance} required min="0" step="any" />

        <div className="flex justify-end space-x-3 pt-3">
          <Button type="button" onClick={onClose} variant="ghost" disabled={isLoadingData}>
            Cancel
          </Button>
          <Button type="submit" isLoading={isLoadingData} variant="primary">
            Save Changes
          </Button>
        </div>
      </form>
    </Modal>
  );
};

export default EditUserModal;