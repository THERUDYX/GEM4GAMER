

import React, { useState, useEffect } from 'react';
import { Tournament, AlertMessage } from '../../types';
import Modal from '../ui/Modal';
import Input from '../ui/Input';
import Button from '../ui/Button';
import { useData } from '../../hooks/useData';
import { useAuth } from '../../hooks/useAuth';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage
import { formatCurrency } from '../../utils/helpers';
import Alert from '../ui/Alert';
import { CURRENCY_SYMBOL } from '../../constants';

interface JoinTournamentModalProps {
  isOpen: boolean;
  onClose: () => void;
  tournament: Tournament | null;
  onJoinSuccess: () => void; 
}

const JoinTournamentModal: React.FC<JoinTournamentModalProps> = ({ isOpen, onClose, tournament, onJoinSuccess }) => {
  const [gameName, setGameName] = useState('');
  const [alertInfo, setAlertInfo] = useState<AlertMessage | null>(null);
  const { joinTournament, isLoadingData } = useData();
  const { currentUser } = useAuth();
  // const { t, language } = useLanguage(); // Removed useLanguage

  useEffect(() => {
    if (isOpen) {
      setGameName('');
      setAlertInfo(null);
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlertInfo(null);
    const currencySymbol = CURRENCY_SYMBOL;

    if (!tournament || !currentUser) {
      setAlertInfo({ id: 'joinErrState', type: 'error', message: "User or tournament data is missing." });
      return;
    }
    if (!gameName.trim()) {
      setAlertInfo({ id: 'joinErrGameName', type: 'error', message: "In-game name is required." });
      return;
    }
    if (currentUser.balance < tournament.entryFee) {
       setAlertInfo({ id: 'joinErrBalance', type: 'error', message: `Insufficient balance. You need ${formatCurrency(tournament.entryFee, currencySymbol)}.` });
      return;
    }

    try {
      const success = await joinTournament(tournament.id, currentUser.id, gameName.trim());
      if (success) {
        setAlertInfo({ id: 'joinSuccess', type: 'success', message: `Successfully joined ${tournament.name}! Your in-game name: ${gameName.trim()}` });
        onJoinSuccess(); 
        setTimeout(() => {
          onClose();
        }, 2000);
      } else {
        setAlertInfo({ id: 'joinFailGeneral', type: 'error', message: "Failed to join tournament. Please try again." });
      }
    } catch (error: any) {
      setAlertInfo({ id: 'joinFailCatch', type: 'error', message: error.message || "An unexpected error occurred." });
    }
  };

  if (!tournament) return null;
  const currencySymbol = CURRENCY_SYMBOL;
  const modalTitle = `Join: ${tournament.name}`;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={modalTitle} size="md">
      {alertInfo && <Alert alert={alertInfo} onDismiss={() => setAlertInfo(null)} />}
      <div className="space-y-4">
        <p className="text-sm text-neutral-light">
          Confirm your participation in {tournament.name}.
        </p>
        <p className="text-sm text-neutral-light">
          Entry Fee: <strong className="text-accent">{formatCurrency(tournament.entryFee, currencySymbol)}</strong>
        </p>
         <p className="text-sm text-neutral-light">
          Your current balance: <strong className="text-accent">{formatCurrency(currentUser?.balance || 0, currencySymbol)}</strong>
        </p>

        <form onSubmit={handleSubmit} className="space-y-4 pt-2">
          <Input
            label="Your In-Game Name (for this tournament)"
            id="ingame-name"
            name="ingame-name"
            type="text"
            value={gameName}
            onChange={(e) => setGameName(e.target.value)}
            required
            placeholder="e.g., Player123"
            Icon={() => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" /></svg>}
          />
          <div className="flex justify-end space-x-3 pt-2">
            <Button type="button" onClick={onClose} variant="ghost" disabled={isLoadingData}>
              Cancel
            </Button>
            <Button type="submit" isLoading={isLoadingData} variant="primary">
              Confirm & Join ({formatCurrency(tournament.entryFee, currencySymbol)})
            </Button>
          </div>
        </form>
      </div>
    </Modal>
  );
};

export default JoinTournamentModal;