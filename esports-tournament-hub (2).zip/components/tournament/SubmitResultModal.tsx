

import React, { useState, useEffect } from 'react';
import { Tournament, AlertMessage } from '../../types';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import { useData } from '../../hooks/useData';
import { useAuth } from '../../hooks/useAuth';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage
import Alert from '../ui/Alert';

interface SubmitResultModalProps {
  isOpen: boolean;
  onClose: () => void;
  tournament: Tournament | null;
  onResultSubmitted: () => void; 
}

const SubmitResultModal: React.FC<SubmitResultModalProps> = ({ isOpen, onClose, tournament, onResultSubmitted }) => {
  const [resultImageFile, setResultImageFile] = useState<File | null>(null);
  const [resultImagePreview, setResultImagePreview] = useState<string | null>(null);
  const [alertInfo, setAlertInfo] = useState<AlertMessage | null>(null);
  const { submitTournamentResult, isLoadingData } = useData();
  const { currentUser } = useAuth();
  // const { t } = useLanguage(); // Removed useLanguage

  useEffect(() => {
    if (isOpen) {
      setResultImageFile(null);
      setResultImagePreview(null);
      setAlertInfo(null);
    }
  }, [isOpen]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!['image/jpeg', 'image/png'].includes(file.type)) {
        setAlertInfo({ id: 'fileTypeError', type: 'error', message: "Invalid file type. Please upload a JPG or PNG image." });
        setResultImageFile(null);
        setResultImagePreview(null);
        event.target.value = '';
        return;
      }
      if (file.size > 2 * 1024 * 1024) { // Max 2MB
        setAlertInfo({ id: 'fileSizeError', type: 'error', message: "File is too large. Maximum size is 2MB." });
        setResultImageFile(null);
        setResultImagePreview(null);
        event.target.value = '';
        return;
      }
      setResultImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setResultImagePreview(reader.result as string); 
      };
      reader.readAsDataURL(file);
      setAlertInfo(null); 
    } else {
      setResultImageFile(null);
      setResultImagePreview(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlertInfo(null);

    if (!tournament || !currentUser) {
      setAlertInfo({ id: 'submitErrState', type: 'error', message: "User or tournament data is missing." });
      return;
    }
    if (!resultImagePreview) {
      setAlertInfo({ id: 'submitErrFile', type: 'error', message: "Please upload a result screenshot." });
      return;
    }

    try {
      const updatedTournament = await submitTournamentResult(tournament.id, currentUser.id, resultImagePreview);
      if (updatedTournament) {
        setAlertInfo({ id: 'submitSuccess', type: 'success', message: `Result submitted successfully for ${tournament.name}!` });
        onResultSubmitted();
        setTimeout(() => {
          onClose();
        }, 2000);
      } else {
        setAlertInfo({ id: 'submitFailGeneral', type: 'error', message: "Failed to submit result. Please try again." });
      }
    } catch (error: any) {
      setAlertInfo({ id: 'submitFailCatch', type: 'error', message: error.message || "An unexpected error occurred." });
    }
  };

  if (!tournament) return null;
  const modalTitle = `Submit Result: ${tournament.name}`;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={modalTitle} size="lg">
      {alertInfo && <Alert alert={alertInfo} onDismiss={() => setAlertInfo(null)} />}
      <div className="space-y-4">
        <p className="text-sm text-neutral-light">
          Upload a screenshot of your result for the tournament: {tournament.name}.
        </p>
        <p className="text-xs text-neutral-dark">
          Ensure the image clearly shows your in-game name and the final result/ranking. Max file size: 2MB (JPG, PNG).
        </p>

        <form onSubmit={handleSubmit} className="space-y-5 pt-2">
          <div>
            <label htmlFor="result-screenshot" className="block text-sm font-medium text-neutral-light mb-1.5">
              Result Screenshot <span className="text-error">*</span>
            </label>
            <input
              id="result-screenshot"
              name="result-screenshot"
              type="file"
              accept="image/png, image/jpeg"
              onChange={handleFileChange}
              required
              className="block w-full text-sm text-neutral-light file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-secondary file:text-primary-dark hover:file:bg-secondary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-secondary focus:ring-offset-background-paper"
            />
            {resultImagePreview && (
              <div className="mt-3 p-2 border border-primary-dark rounded-md bg-primary-light inline-block">
                <img src={resultImagePreview} alt="Result screenshot preview" className="max-h-60 max-w-full rounded shadow-sm" />
              </div>
            )}
          </div>

          <div className="flex justify-end space-x-3 pt-3">
            <Button type="button" onClick={onClose} variant="ghost" disabled={isLoadingData}>
              Cancel
            </Button>
            <Button type="submit" isLoading={isLoadingData} variant="primary" disabled={!resultImagePreview}>
              Submit Result
            </Button>
          </div>
        </form>
      </div>
    </Modal>
  );
};

export default SubmitResultModal;