

import React from 'react';
import { Tournament, TournamentStatus } from '../../types';
import { formatCurrency, formatDate } from '../../utils/helpers';
import Button from '../ui/Button';
import CountdownTimer from '../ui/CountdownTimer'; 
import { CURRENCY_SYMBOL } from '../../constants';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage

interface TournamentCardProps {
  tournament: Tournament;
  onJoin?: (tournamentId: string) => void;
  onViewDetails?: (tournament: Tournament) => void;
  isJoined?: boolean; 
  canJoin?: boolean;
}

const TournamentCard: React.FC<TournamentCardProps> = ({ tournament, onJoin, onViewDetails, isJoined, canJoin }) => {
  // const { t, language } = useLanguage(); // Removed useLanguage

  const getStatusText = (status: TournamentStatus) => {
    switch (status) {
      case TournamentStatus.UPCOMING: return "Upcoming";
      case TournamentStatus.ONGOING: return "Ongoing";
      case TournamentStatus.COMPLETED: return "Completed";
      default: return status;
    }
  };
  
  const getStatusColor = (status: TournamentStatus) => {
    switch (status) {
      case TournamentStatus.UPCOMING: return 'text-yellow-400 border-yellow-400';
      case TournamentStatus.ONGOING: return 'text-green-400 border-green-400';
      case TournamentStatus.COMPLETED: return 'text-gray-400 border-gray-400';
      default: return 'text-neutral-light border-neutral-light';
    }
  };

  const isFull = tournament.participants.length >= tournament.maxParticipants;
  const showJoinButton = canJoin && tournament.status === TournamentStatus.UPCOMING && !isJoined && !isFull && onJoin;
  const currencySymbol = CURRENCY_SYMBOL;

  return (
    <div className="bg-primary-light rounded-xl shadow-xl overflow-hidden transform hover:scale-105 hover:shadow-2xl hover:shadow-primary-dark/70 transition-all duration-300 ease-in-out flex flex-col border-l-4 border-accent">
      <img src={tournament.imageUrl} alt={tournament.name} className="w-full h-52 object-cover"/>
      <div className="p-5 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-secondary truncate" title={tournament.name}>{tournament.name}</h3>
          <span className={`px-2.5 py-1 text-xs font-semibold rounded-full border ${getStatusColor(tournament.status)}`}>
            {getStatusText(tournament.status)}
          </span>
        </div>
        <p className="text-sm text-accent mb-1 font-medium">{tournament.game}</p>
        <p className="text-xs text-neutral-default mb-2">{formatDate(tournament.scheduleDate)}</p>
        
        {tournament.status === TournamentStatus.UPCOMING && (
            <CountdownTimer scheduleDate={tournament.scheduleDate} className="text-sm font-medium text-secondary mb-3"/>
        )}
        
        <div className="space-y-1.5 text-sm mb-4">
          <p className="text-neutral-light">Entry: <span className="font-semibold text-white">{formatCurrency(tournament.entryFee, currencySymbol)}</span></p>
          <p className="text-neutral-light">Prize: <span className="font-semibold text-white">{formatCurrency(tournament.prizePool, currencySymbol)}</span></p>
          <p className="text-neutral-light">Spots: <span className="font-semibold text-white">{tournament.participants.length} / {tournament.maxParticipants}</span></p>
        </div>

        <div className="mt-auto pt-3 border-t border-primary-dark/50 flex space-x-2">
          {onViewDetails && (
            <Button onClick={() => onViewDetails(tournament)} variant="outline" size="sm" className="flex-1">
              Details
            </Button>
          )}
          
          {showJoinButton && (
            <Button onClick={() => onJoin!(tournament.id)} variant="primary" size="sm" className="flex-1">
              Join Now
            </Button>
          )}

          {canJoin && tournament.status === TournamentStatus.UPCOMING && !isJoined && isFull && (
             <span className="flex-1 text-center py-2 text-sm text-error font-semibold border-2 border-error rounded-lg">Full</span>
          )}
          
          {isJoined && (
             <span className="flex-1 text-center py-2 text-sm text-success font-semibold border-2 border-success rounded-lg">Joined</span>
          )}

           {!canJoin && tournament.status === TournamentStatus.UPCOMING && !isFull && ( 
             <span className="flex-1 text-center py-2 text-sm text-neutral-dark font-semibold border-2 border-neutral-dark rounded-lg">Login to Join</span>
          )}
           {!canJoin && tournament.status === TournamentStatus.UPCOMING && isFull && ( 
             <span className="flex-1 text-center py-2 text-sm text-error font-semibold border-2 border-error rounded-lg">Full</span>
          )}
        </div>
      </div>
    </div>
  );
};

export default TournamentCard;