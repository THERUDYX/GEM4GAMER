

import React from 'react';
import { Tournament, TournamentStatus } from '../../types';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import { formatCurrency, formatDate } from '../../utils/helpers';
import CountdownTimer from '../ui/CountdownTimer';
import { useAuth } from '../../hooks/useAuth'; 
import { CURRENCY_SYMBOL } from '../../constants';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage

interface TournamentDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  tournament: Tournament | null;
}

const TournamentDetailsModal: React.FC<TournamentDetailsModalProps> = ({ isOpen, onClose, tournament }) => {
  const { currentUser } = useAuth();
  // const { t, language } = useLanguage(); // Removed useLanguage

  if (!tournament) return null;

  const currentUserParticipation = currentUser 
    ? tournament.participants.find(p => p.userId === currentUser.id) 
    : undefined;
  
  const isUserJoined = !!currentUserParticipation;
  const showRoomDetails = isUserJoined && (tournament.roomId || tournament.roomPassword);
  const adminProvidedRoomDetails = tournament.roomId || tournament.roomPassword;
  const currencySymbol = CURRENCY_SYMBOL;

  const getStatusText = (status: TournamentStatus) => {
    switch (status) {
      case TournamentStatus.UPCOMING: return "Upcoming";
      case TournamentStatus.ONGOING: return "Ongoing";
      case TournamentStatus.COMPLETED: return "Completed";
      default: return status;
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={tournament.name} size="lg">
      <div className="space-y-4">
        <img src={tournament.imageUrl} alt={tournament.name} className="w-full h-64 object-cover rounded-md mb-4"/>
        
        {tournament.status === TournamentStatus.UPCOMING && (
          <div className="mb-3 text-center">
            <CountdownTimer scheduleDate={tournament.scheduleDate} className="text-lg font-semibold text-secondary"/>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div><strong className="text-neutral-light">Game:</strong> <span className="text-accent">{tournament.game}</span></div>
          <div><strong className="text-neutral-light">Status:</strong> <span className={`font-semibold ${
            tournament.status === TournamentStatus.UPCOMING ? 'text-yellow-400' :
            tournament.status === TournamentStatus.ONGOING ? 'text-green-400' : 'text-gray-400'
          }`}>{getStatusText(tournament.status)}</span></div>
          <div><strong className="text-neutral-light">Schedule:</strong> <span className="text-neutral-default">{formatDate(tournament.scheduleDate)}</span></div>
          <div><strong className="text-neutral-light">Entry Fee:</strong> <span className="text-neutral-default">{formatCurrency(tournament.entryFee, currencySymbol)}</span></div>
          <div><strong className="text-neutral-light">Prize Pool:</strong> <span className="text-neutral-default">{formatCurrency(tournament.prizePool, currencySymbol)}</span></div>
          <div><strong className="text-neutral-light">Participants:</strong> <span className="text-neutral-default">{tournament.participants.length} / {tournament.maxParticipants} joined</span></div>
        </div>

        {isUserJoined && currentUserParticipation?.gameName && (
           <div className="mt-3 pt-3 border-t border-primary-light/30">
             <p className="text-sm"><strong className="text-neutral-light">Your In-Game Name:</strong> <span className="text-secondary font-semibold">{currentUserParticipation.gameName}</span></p>
           </div>
        )}

        {isUserJoined && (
          <div className="mt-4 pt-4 border-t border-primary-light">
            <h4 className="text-lg font-semibold text-secondary mb-2">Room Details</h4>
            {showRoomDetails ? (
              <>
                {tournament.roomId && <p><strong className="text-neutral-light">Room ID:</strong> <span className="text-accent">{tournament.roomId}</span></p>}
                {tournament.roomPassword && <p><strong className="text-neutral-light">Password:</strong> <span className="text-accent">{tournament.roomPassword}</span></p>}
              </>
            ) : (
              <p className="text-neutral-dark text-sm">
                { adminProvidedRoomDetails 
                    ? "Room details are hidden until start or specific conditions."
                    : "Room details will be available closer to the tournament start time or once provided by the admin."
                }
              </p>
            )}
          </div>
        )}

        {isUserJoined && tournament.status === TournamentStatus.UPCOMING && !adminProvidedRoomDetails && (
            <p className="mt-4 text-sm text-green-400">You have successfully joined this tournament. Room details will be provided by the admin closer to the start time.</p>
        )}
         {isUserJoined && (tournament.status === TournamentStatus.ONGOING || tournament.status === TournamentStatus.COMPLETED) && !adminProvidedRoomDetails && (
             <p className="mt-4 text-sm text-neutral-dark">Room details for this tournament were not provided or are communicated through other channels.</p>
         )}

      </div>
      <div className="mt-6 flex justify-end">
        <Button onClick={onClose} variant="outline">Close</Button>
      </div>
    </Modal>
  );
};

export default TournamentDetailsModal;