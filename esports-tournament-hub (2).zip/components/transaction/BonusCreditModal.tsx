

import React, { useState, useEffect } from 'react';
import { User, AlertMessage } from '../../types';
import Modal from '../ui/Modal';
import Input from '../ui/Input';
import Button from '../ui/Button';
import { useData } from '../../hooks/useData';
import { formatCurrency } from '../../utils/helpers';
import Alert from '../ui/Alert';
import { CURRENCY_SYMBOL } from '../../constants';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage

interface BonusCreditModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
}

const BonusCreditModal: React.FC<BonusCreditModalProps> = ({ isOpen, onClose, user }) => {
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');
  const { grantBonusCredit, isLoadingData } = useData();
  // const { t, language } = useLanguage(); // Removed useLanguage
  const [alertInfo, setAlertInfo] = useState<AlertMessage | null>(null);

  useEffect(() => {
    if (isOpen) {
      setAmount('');
      setNotes('');
      setAlertInfo(null);
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlertInfo(null);
    const currencySymbol = CURRENCY_SYMBOL;
    if (!user || !amount || parseFloat(amount) <= 0) {
      setAlertInfo({ id: 'bonusErrAmount', type: 'error', message: "Please enter a valid bonus amount." });
      return;
    }
    const bonusAmount = parseFloat(amount);

    try {
      const transaction = await grantBonusCredit(user.id, bonusAmount, notes);
      if (transaction) {
        setAlertInfo({ id: 'bonusSuccess', type: 'success', message: `Bonus credit of ${formatCurrency(bonusAmount, currencySymbol)} granted to ${user.username}.` });
        setTimeout(() => {
          onClose();
        }, 2000);
      } else {
        throw new Error("Transaction failed while granting bonus.");
      }
    } catch (error) {
       setAlertInfo({ id: 'bonusFail', type: 'error', message: (error as Error).message || "Failed to grant bonus credit." });
    }
  };

  if (!user) return null;
  const currencySymbol = CURRENCY_SYMBOL;
  const modalTitle = `Grant Bonus Credit to ${user.username}`;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={modalTitle} size="md">
      {alertInfo && <Alert alert={alertInfo} onDismiss={() => setAlertInfo(null)} />}
      <div className="mb-4">
        <p className="text-sm text-neutral-light">Current Balance: <span className="font-semibold text-secondary">{formatCurrency(user.balance, currencySymbol)}</span></p>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input
          label={`Bonus Amount (${currencySymbol})`}
          id="bonus-amount"
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          min="0.01"
          step="any"
          required
          placeholder="e.g. 100"
          Icon={() => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M21 12a2.25 2.25 0 00-2.25-2.25H15a3 3 0 11-6 0H5.25A2.25 2.25 0 003 12m18 0v6.248a2.25 2.25 0 01-2.25 2.25h-13.5A2.25 2.25 0 013 18.248V12m18 0c0 2.47-2.03 4.498-4.502 4.498S14.998 14.47 14.998 12M3 12c0 2.47 2.03 4.498 4.502 4.498S12.002 14.47 12.002 12" /></svg>}
        />
        <Input
            label="Notes (Optional)"
            id="bonus-notes"
            name="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Reason for bonus"
            // @ts-ignore
            as="textarea"
            rows={3}
            Icon={() => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125" /></svg>}
        />
        <div className="flex justify-end space-x-3 pt-2">
          <Button type="button" onClick={onClose} variant="ghost">Cancel</Button>
          <Button type="submit" isLoading={isLoadingData} variant="primary">Confirm Bonus</Button>
        </div>
      </form>
    </Modal>
  );
};

export default BonusCreditModal;