

import React, { useState, useEffect } from 'react';
import { AdminBankDetails, AlertMessage } from '../../types';
import Modal from '../ui/Modal';
import Input from '../ui/Input';
import Button from '../ui/Button';
import { useData } from '../../hooks/useData';
import { useAuth } from '../../hooks/useAuth';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage
import Alert from '../ui/Alert';
import { formatDate } from '../../utils/helpers';
import { CURRENCY_SYMBOL } from '../../constants';

interface DepositModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const WhatsappIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
    <path fillRule="evenodd" d="M18.403 5.633A8.919 8.919 0 0012.053 3c-4.948 0-8.976 4.027-8.976 8.974 0 1.582.413 3.126 1.198 4.488L3 21.116l4.759-1.249a8.981 8.981 0 004.29 1.093h.004c4.947 0 8.975-4.027 8.975-8.973a8.926 8.926 0 00-2.627-6.354zm-6.35 13.812h-.004a7.446 7.446 0 01-3.798-1.041l-.272-.162-2.824.741.753-2.753-.177-.289a7.448 7.448 0 01-1.141-3.971c0-4.108 3.341-7.448 7.448-7.448s7.448 3.34 7.448 7.448-3.34 7.448-7.448 7.448zm4.093-5.374c-.225-.113-1.327-.655-1.533-.73-.205-.075-.354-.112-.504.112s-.58.729-.711.879-.262.168-.486.056-.947-.349-1.804-1.113c-.667-.595-1.117-1.329-1.248-1.554s-.019-.354.09-.465c.099-.1.224-.262.336-.393.112-.131.149-.224.224-.374s.038-.281-.019-.393c-.056-.113-.505-1.217-.692-1.666-.181-.435-.366-.377-.504-.383a9.65 9.65 0 00-.429-.008.826.826 0 00-.598.28c-.206.225-.788.766-.788 1.871s.807 2.171.921 2.321c.112.15 1.582 2.415 3.832 3.387.536.231.954.369 1.279.473.537.171 1.026.148 1.407.089.431-.064 1.327-.542 1.514-1.066.187-.524.187-.973.131-1.067-.056-.094-.207-.151-.43-.263z" clipRule="evenodd" />
  </svg>
);


const DepositModal: React.FC<DepositModalProps> = ({ isOpen, onClose }) => {
  const [amount, setAmount] = useState('');
  const [utrNumber, setUtrNumber] = useState(''); // Added UTR state
  const [screenshotFile, setScreenshotFile] = useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const { adminBankDetails, requestDeposit, isLoadingData, fetchAdminBankDetails } = useData();
  const { currentUser } = useAuth();
  // const { t, language } = useLanguage(); // Removed useLanguage
  const [alert, setAlert] = useState<AlertMessage | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetchAdminBankDetails();
      setAmount(''); 
      setUtrNumber(''); // Reset UTR
      setScreenshotFile(null);
      setScreenshotPreview(null);
      setAlert(null); 
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // Max 2MB
        setAlert({ id: 'fileSizeError', type: 'error', message: "File is too large. Maximum size is 2MB." });
        setScreenshotFile(null);
        setScreenshotPreview(null);
        event.target.value = ''; 
        return;
      }
      setScreenshotFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshotPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setScreenshotFile(null);
      setScreenshotPreview(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlert(null);
    const currencySymbol = CURRENCY_SYMBOL;
    if (!currentUser || !amount || parseFloat(amount) <= 0) {
      setAlert({ id: 'depositErrorAmount', type: 'error', message: "Please enter a valid amount." });
      return;
    }
    if (!utrNumber.trim()) {
      setAlert({ id: 'depositErrorUTR', type: 'error', message: "Please enter the UTR/Transaction ID." });
      return;
    }
    if (!screenshotFile || !screenshotPreview) {
      setAlert({ id: 'depositErrorFile', type: 'error', message: "Please upload a payment screenshot." });
      return;
    }
    const depositAmount = parseFloat(amount);
    const transaction = await requestDeposit(currentUser.id, depositAmount, screenshotPreview, utrNumber.trim());
    if (transaction) {
      setAlert({ id: 'depositSuccess', type: 'success', message: `Deposit request for ${currencySymbol}${depositAmount.toString()} submitted. It will be reviewed by an admin.` });
      setTimeout(() => {
         onClose(); 
      }, 2500);
    } else {
      setAlert({ id: 'depositFail', type: 'error', message: "Failed to submit deposit request. Please try again." });
    }
  };
  const currencySymbol = CURRENCY_SYMBOL;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Deposit Funds" size="lg">
      {alert && <Alert alert={alert} onDismiss={() => setAlert(null)} />}
      {isLoadingData && !adminBankDetails && <p className="text-neutral-light">Loading bank details...</p>}
      {!isLoadingData && !adminBankDetails && <p className="text-error">Admin bank details are not available. Please contact support.</p>}
      
      {adminBankDetails && (
        <div className="space-y-4">
          <div>
            <h4 className="text-lg font-semibold text-secondary mb-2">Payment Options</h4>
            <div className="border border-primary-light p-3 rounded-lg bg-primary-light/30">
              <h5 className="text-md font-medium text-neutral-light mb-2">1. Bank Transfer / UPI</h5>
              <p className="text-sm text-neutral-default mb-2">Please transfer funds to the following account and then submit your deposit request below with the UTR/Transaction ID and a screenshot of the payment:</p>
              <div className="mt-2 p-3 bg-primary-dark rounded-md text-sm space-y-1">
                <p><strong className="text-neutral-default">Account Holder:</strong> {adminBankDetails.accountHolderName}</p>
                <p><strong className="text-neutral-default">Account Number:</strong> {adminBankDetails.accountNumber}</p>
                <p><strong className="text-neutral-default">Bank Name:</strong> {adminBankDetails.bankName}</p>
                <p><strong className="text-neutral-default">IFSC Code:</strong> {adminBankDetails.ifscCode}</p>
                {adminBankDetails.upiId && <p><strong className="text-neutral-default">UPI ID:</strong> {adminBankDetails.upiId}</p>}
              </div>
              {adminBankDetails.qrCodeImageUrl && (
                <div className="mt-3">
                  <p className="text-sm font-semibold text-neutral-light">Or Scan QR Code:</p>
                  <img src={adminBankDetails.qrCodeImageUrl} alt="Payment QR Code" className="max-w-xs h-auto rounded-md border border-primary-dark mt-1" />
                </div>
              )}
              <p className="text-xs text-neutral-dark mt-2">Last updated: {formatDate(adminBankDetails.lastUpdated)}</p>
            </div>

            <div className="mt-4 border border-primary-light p-3 rounded-lg bg-primary-light/30">
                <h5 className="text-md font-medium text-neutral-light mb-2">2. Deposit via WhatsApp</h5>
                <p className="text-sm text-neutral-default mb-3">Click the button below to initiate a deposit request via WhatsApp. Our team will guide you through the process.</p>
                <Button 
                    onClick={() => window.open('https://wa.me/916203929125', '_blank')} 
                    variant="secondary" 
                    IconLeft={WhatsappIcon}
                    className="bg-green-500 hover:bg-green-600 text-white focus:ring-green-400"
                >
                    Deposit via WhatsApp
                </Button>
            </div>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-4 pt-4 border-t border-primary-light">
            <h4 className="text-lg font-semibold text-secondary mb-1">Submit Bank Transfer / UPI Details</h4>
             <Input
              label={`Amount Deposited (${currencySymbol})`}
              id="deposit-amount"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              min="1"
              step="any"
              required
              placeholder="e.g., 500"
            />
            <Input
              label="UTR / Transaction ID"
              id="utr-number"
              type="text"
              value={utrNumber}
              onChange={(e) => setUtrNumber(e.target.value)}
              required
              placeholder="Enter the UTR or Transaction ID from your payment"
            />
            <div>
              <label htmlFor="payment-screenshot" className="block text-sm font-medium text-neutral-light mb-1">
                Payment Screenshot (Max 2MB, JPG/PNG) <span className="text-error">*</span>
              </label>
              <input
                id="payment-screenshot"
                name="payment-screenshot"
                type="file"
                accept="image/png, image/jpeg"
                onChange={handleFileChange}
                required
                className="block w-full text-sm text-neutral-light file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-secondary file:text-primary-dark hover:file:bg-secondary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-secondary focus:ring-offset-background-paper"
              />
              {screenshotPreview && (
                <div className="mt-2">
                  <img src={screenshotPreview} alt="Payment screenshot preview" className="max-h-40 rounded-md border border-primary-dark" />
                </div>
              )}
            </div>
            <div className="flex justify-end space-x-2">
              <Button type="button" onClick={onClose} variant="ghost">Cancel</Button>
              <Button type="submit" isLoading={isLoadingData} variant="primary">Submit Deposit Request</Button>
            </div>
          </form>
        </div>
      )}
    </Modal>
  );
};

export default DepositModal;