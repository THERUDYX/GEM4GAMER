

import React from 'react';
import { Transaction, TransactionStatus, TransactionType } from '../../types';
import { formatCurrency, formatDate } from '../../utils/helpers';
import { CURRENCY_SYMBOL } from '../../constants';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage

interface TransactionItemProps {
  transaction: Transaction;
}

const TransactionItem: React.FC<TransactionItemProps> = ({ transaction }) => {
  // const { t, language } = useLanguage(); // Removed useLanguage

  const getStatusColor = (status: TransactionStatus) => {
    switch (status) {
      case TransactionStatus.PENDING: return 'text-yellow-400';
      case TransactionStatus.CONFIRMED: return 'text-green-400';
      case TransactionStatus.DECLINED: return 'text-red-400';
      default: return 'text-neutral-light';
    }
  };

  const getTransactionTypeText = (type: TransactionType) => {
    switch (type) {
      case TransactionType.DEPOSIT: return { text: "Deposit", color: 'text-blue-400' };
      case TransactionType.WITHDRAWAL: return { text: "Withdrawal", color: 'text-purple-400' };
      case TransactionType.TOURNAMENT_ENTRY: return { text: "Tournament Entry", color: 'text-pink-400' };
      case TransactionType.BONUS_CREDIT: return { text: "Bonus Credit", color: 'text-teal-400' };
      default: return { text: type, color: 'text-neutral-light' };
    }
  };
  
  const getTransactionStatusText = (status: TransactionStatus) => {
     switch (status) {
      case TransactionStatus.PENDING: return "Pending";
      case TransactionStatus.CONFIRMED: return "Confirmed";
      case TransactionStatus.DECLINED: return "Declined";
      default: return status;
    }
  }

  const typeInfo = getTransactionTypeText(transaction.type);
  const isCredit = transaction.type === TransactionType.DEPOSIT || transaction.type === TransactionType.BONUS_CREDIT;
  const currencySymbol = CURRENCY_SYMBOL;

  return (
    <li className="py-4 px-3 hover:bg-primary-light/70 transition-colors duration-200 rounded-lg">
      <div className="flex items-center space-x-4">
        <div className="flex-shrink-0 p-2 bg-primary-dark rounded-full">
          {transaction.type === TransactionType.DEPOSIT && <DepositIcon />}
          {transaction.type === TransactionType.WITHDRAWAL && <WithdrawIcon />}
          {transaction.type === TransactionType.TOURNAMENT_ENTRY && <TrophyIcon />}
          {transaction.type === TransactionType.BONUS_CREDIT && <GiftIcon />}
        </div>
        <div className="flex-1 min-w-0">
          <p className={`text-sm font-semibold ${typeInfo.color} truncate`}>{typeInfo.text}</p>
          <p className="text-xs text-neutral-default truncate">{transaction.description}</p>
          <p className="text-xs text-neutral-dark">{formatDate(transaction.date)}</p>
        </div>
        <div className="text-right">
          <p className={`text-sm font-bold ${isCredit ? 'text-success' : 'text-error'}`}>
            {isCredit ? '+' : '-'}{formatCurrency(transaction.amount, currencySymbol)}
          </p>
          <p className={`text-xs font-medium ${getStatusColor(transaction.status)}`}>{getTransactionStatusText(transaction.status)}</p>
        </div>
      </div>
      {transaction.adminNotes && (
        <p className="mt-1.5 text-xs text-neutral-dark italic pl-16">Admin note: {transaction.adminNotes}</p>
      )}
       {transaction.type === TransactionType.WITHDRAWAL && transaction.userBankDetails && (
        <div className="mt-1.5 text-xs text-neutral-dark pl-16">
            <p>To: {transaction.userBankDetails.accountHolderName} ({transaction.userBankDetails.bankName} - A/C: ...{transaction.userBankDetails.accountNumber.slice(-4)})</p>
        </div>
      )}
    </li>
  );
};

const DepositIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-blue-400">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m0 0l-6.75-6.75M12 19.5l6.75-6.75M3.75 12h16.5" />
  </svg>
);
const WithdrawIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-purple-400">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 19.5V4.5m0 0L5.25 11.25M12 4.5l6.75 6.75M3.75 12h16.5" />
  </svg>
);
const TrophyIcon = () => (
 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-pink-400">
  <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 18.75h-9m9 0a3 3 0 013 3h-15a3 3 0 013-3m9 0v-4.5A3.375 3.375 0 0012.75 9.75H11.25A3.375 3.375 0 007.5 13.125V18.75m9 0h1.5a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v9.75A2.25 2.25 0 004.5 18.75H6M12 9V6.75A3.375 3.375 0 008.625 3.375H7.5A3.375 3.375 0 004.125 6.75V9" />
</svg>
);
const GiftIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 text-teal-400">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 3.75v16.5M7.5 7.5h9M7.5 12h9m-9 4.5h9M5.25 3.75h13.5a1.5 1.5 0 011.5 1.5v13.5a1.5 1.5 0 01-1.5 1.5h-13.5a1.5 1.5 0 01-1.5-1.5v-13.5a1.5 1.5 0 011.5-1.5z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 3.75C10.5 5.269 9.269 6.5 7.75 6.5S5 5.269 5 3.75m14 0c0 1.519-1.231 2.75-2.75 2.75S13.5 5.269 13.5 3.75" />
  </svg>
);

export default TransactionItem;