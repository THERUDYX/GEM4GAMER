

import React from 'react';
import { Transaction } from '../../types';
import TransactionItem from './TransactionItem';
import LoadingSpinner from '../ui/LoadingSpinner';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage

interface TransactionListProps {
  transactions: Transaction[];
  isLoading?: boolean;
  title?: string;
}

const EmptyStateIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16 text-primary-light mb-4">
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
  </svg>
);


const TransactionList: React.FC<TransactionListProps> = ({ transactions, isLoading, title }) => {
  // const { t } = useLanguage(); // Removed useLanguage

  if (isLoading) {
    return <LoadingSpinner text={"Loading transactions..."} className="my-10" />;
  }
  
  const displayTitle = title || "Transaction History";


  return (
    <div className="bg-background-paper shadow-xl rounded-xl border-l-4 border-accent">
      <h3 className="text-xl font-semibold text-neutral-light p-5 border-b border-primary-light tracking-tight">{displayTitle}</h3>
      {transactions.length === 0 ? (
        <div className="text-center text-neutral-default py-12 px-6">
            <EmptyStateIcon/>
            <p className="text-lg">No transactions found yet.</p>
            <p className="text-sm text-neutral-dark">Your deposits, withdrawals, and tournament entries will appear here.</p>
        </div>
      ) : (
        <ul className="divide-y divide-primary-light max-h-[500px] overflow-y-auto p-2">
          {transactions.map(transaction => (
            <TransactionItem key={transaction.id} transaction={transaction} />
          ))}
        </ul>
      )}
    </div>
  );
};

export default TransactionList;