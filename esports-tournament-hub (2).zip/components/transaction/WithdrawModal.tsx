

import React, { useState, useEffect } from 'react';
import { UserBankDetails, AlertMessage } from '../../types';
import Modal from '../ui/Modal';
import Input from '../ui/Input';
import Button from '../ui/Button';
import { useData } from '../../hooks/useData';
import { useAuth } from '../../hooks/useAuth';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage
import { formatCurrency } from '../../utils/helpers';
import Alert from '../ui/Alert';
import { CURRENCY_SYMBOL } from '../../constants';

interface WithdrawModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const WithdrawModal: React.FC<WithdrawModalProps> = ({ isOpen, onClose }) => {
  const [amount, setAmount] = useState('');
  const [bankDetails, setBankDetails] = useState<UserBankDetails>({
    accountHolderName: '',
    accountNumber: '',
    bankName: '',
    ifscCode: '',
  });
  const { requestWithdrawal, isLoadingData } = useData();
  const { currentUser } = useAuth();
  // const { t, language } = useLanguage(); // Removed useLanguage
  const [alert, setAlert] = useState<AlertMessage | null>(null);

  useEffect(() => {
    if (isOpen) {
      setAmount('');
      setBankDetails(currentUser?.bankDetails || { accountHolderName: '', accountNumber: '', bankName: '', ifscCode: '' });
      setAlert(null);
    }
  }, [isOpen, currentUser]);

  const handleBankDetailsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setBankDetails(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlert(null);
    const currencySymbol = CURRENCY_SYMBOL;
    if (!currentUser || !amount || parseFloat(amount) <= 0) {
      setAlert({ id:'withdrawErr', type: 'error', message: "Please enter a valid amount." });
      return;
    }
    const withdrawAmount = parseFloat(amount);
    if (withdrawAmount > currentUser.balance) {
      setAlert({ id:'withdrawErrBal', type: 'error', message: "Insufficient balance for this withdrawal." });
      return;
    }
    if (Object.values(bankDetails).some(val => val.trim() === '')) {
       setAlert({ id:'withdrawErrBank', type: 'error', message: "Please fill in all bank details." });
      return;
    }

    const transaction = await requestWithdrawal(currentUser.id, withdrawAmount, bankDetails);
    if (transaction) {
      setAlert({id:'withdrawSuccess', type: 'success', message: `Withdrawal request for ${currencySymbol}${withdrawAmount.toString()} submitted. It will be reviewed by an admin.` });
       setTimeout(() => {
         onClose();
      }, 2000);
    } else {
      setAlert({id:'withdrawFail', type: 'error', message: "Failed to submit withdrawal request. Please try again." });
    }
  };
  const currencySymbol = CURRENCY_SYMBOL;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Withdraw Funds">
      {alert && <Alert alert={alert} onDismiss={() => setAlert(null)} />}
      <p className="text-sm text-neutral-light mb-4">
        Available balance: <span className="font-semibold text-secondary">{formatCurrency(currentUser?.balance || 0, currencySymbol)}</span>
      </p>
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input
          label={`Amount to Withdraw (${currencySymbol})`}
          id="withdraw-amount"
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          min="1"
          step="any"
          required
          placeholder="e.g., 500"
        />
        <h4 className="text-md font-semibold text-neutral-light pt-2 border-t border-primary-light">Your Bank Details</h4>
        <Input
          label="Account Holder Name"
          id="accountHolderName"
          name="accountHolderName"
          type="text"
          value={bankDetails.accountHolderName}
          onChange={handleBankDetailsChange}
          required
        />
        <Input
          label="Account Number"
          id="accountNumber"
          name="accountNumber"
          type="text"
          value={bankDetails.accountNumber}
          onChange={handleBankDetailsChange}
          required
        />
        <Input
          label="Bank Name"
          id="bankName"
          name="bankName"
          type="text"
          value={bankDetails.bankName}
          onChange={handleBankDetailsChange}
          required
        />
        <Input
          label="IFSC Code"
          id="ifscCode"
          name="ifscCode"
          type="text"
          value={bankDetails.ifscCode}
          onChange={handleBankDetailsChange}
          required
        />
        <div className="flex justify-end space-x-2 pt-2">
          <Button type="button" onClick={onClose} variant="ghost">Cancel</Button>
          <Button type="submit" isLoading={isLoadingData} variant="primary">Submit Withdrawal Request</Button>
        </div>
      </form>
    </Modal>
  );
};

export default WithdrawModal;