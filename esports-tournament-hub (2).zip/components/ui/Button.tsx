import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
  IconLeft?: React.ElementType;
  IconRight?: React.ElementType;
}

const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  isLoading = false,
  IconLeft,
  IconRight,
  className,
  disabled,
  ...props
}) => {
  const baseStyles = "font-semibold rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-background-DEFAULT inline-flex items-center justify-center transition-all duration-300 ease-in-out transform hover:-translate-y-0.5";

  const sizeStyles = {
    sm: "px-3.5 py-2 text-xs", // Slightly increased padding
    md: "px-5 py-2.5 text-sm", // Slightly increased padding
    lg: "px-7 py-3.5 text-base", // Slightly increased padding
  };

  // Primary button gets a gradient
  const variantStyles = {
    primary: "bg-gradient-to-br from-secondary to-secondary-dark hover:from-secondary-dark hover:to-secondary text-primary-dark focus:ring-secondary hover:shadow-lg hover:shadow-secondary/30",
    secondary: "bg-accent hover:bg-accent-dark text-white focus:ring-accent hover:shadow-md hover:shadow-accent/30",
    danger: "bg-error hover:bg-red-700 text-white focus:ring-error hover:shadow-md hover:shadow-error/30",
    ghost: "bg-transparent hover:bg-primary-light text-secondary focus:ring-secondary",
    outline: "bg-transparent border-2 border-secondary text-secondary hover:bg-secondary hover:text-primary-dark focus:ring-secondary hover:shadow-md hover:shadow-secondary/20"
  };

  const combinedClassName = `
    ${baseStyles}
    ${sizeStyles[size]}
    ${variantStyles[variant]}
    ${(isLoading || disabled) ? 'opacity-60 cursor-not-allowed hover:transform-none hover:shadow-none' : ''}
    ${className || ''}
  `;

  return (
    <button
      className={combinedClassName}
      disabled={isLoading || disabled}
      {...props}
    >
      {isLoading && (
        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-current" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      )}
      {IconLeft && !isLoading && <IconLeft className={`h-5 w-5 ${children ? 'mr-2' : ''}`} />}
      {children}
      {IconRight && !isLoading && <IconRight className={`h-5 w-5 ${children ? 'ml-2' : ''}`} />}
    </button>
  );
};

export default Button;