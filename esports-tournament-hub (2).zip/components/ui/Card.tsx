import React, { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  title?: string;
  actions?: ReactNode;
}

const Card: React.FC<CardProps> = ({ children, className, title, actions }) => {
  return (
    <div 
      className={`
        bg-background-paper shadow-xl rounded-xl overflow-hidden 
        transition-all duration-300 ease-in-out hover:shadow-2xl hover:shadow-primary-dark/50
        border-l-4 border-secondary 
        ${className || ''}
      `}
    >
      {(title || actions) && (
        <div className="p-5 border-b border-primary-light flex justify-between items-center">
          {title && <h3 className="text-xl font-semibold text-neutral-light tracking-tight">{title}</h3>}
          {actions && <div className="flex space-x-2">{actions}</div>}
        </div>
      )}
      <div className="p-5 md:p-6">
        {children}
      </div>
    </div>
  );
};

export default Card;