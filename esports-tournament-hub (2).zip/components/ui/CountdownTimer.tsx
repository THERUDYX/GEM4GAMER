

import React, { useState, useEffect } from 'react';
import { calculateTimeRemaining, formatTimeRemaining } from '../../utils/helpers';
import { TimeRemaining } from '../../types';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage

interface CountdownTimerProps {
  scheduleDate: string;
  className?: string;
  onTimerEnd?: () => void;
}

const CountdownTimer: React.FC<CountdownTimerProps> = ({ scheduleDate, className, onTimerEnd }) => {
  // const { t, translationsLoading } = useLanguage(); // Removed useLanguage
  const [timeRemaining, setTimeRemaining] = useState<TimeRemaining | null>(calculateTimeRemaining(scheduleDate));

  useEffect(() => {
    if (!scheduleDate) return;

    const intervalId = setInterval(() => {
      const newTimeRemaining = calculateTimeRemaining(scheduleDate);
      setTimeRemaining(newTimeRemaining);
      if (newTimeRemaining && newTimeRemaining.totalSeconds <= 0) {
        clearInterval(intervalId);
        if (onTimerEnd) onTimerEnd();
      }
    }, 1000);

    return () => clearInterval(intervalId);
  }, [scheduleDate, onTimerEnd]);

  // if (translationsLoading) { // Removed translationsLoading check
  //    return <span className={className}>Loading...</span>;
  // }

  if (!timeRemaining) {
    return <span className={className}>Loading...</span>;
  }
  
  if (timeRemaining.totalSeconds <=0) {
    return <span className={`${className} text-green-400`}>Event Started / Ongoing</span>;
  }

  return (
    <span className={className}>
      {formatTimeRemaining(timeRemaining)}
    </span>
  );
};

export default CountdownTimer;