import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  Icon?: React.ElementType;
}

const Input: React.FC<InputProps> = ({ label, id, error, Icon, className, ...props }) => {
  return (
    <div className="w-full">
      {label && (
        <label htmlFor={id} className="block text-sm font-medium text-neutral-light mb-1.5">
          {label}
        </label>
      )}
      <div className="relative">
        {Icon && (
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Icon className="h-5 w-5 text-neutral-dark" aria-hidden="true" />
          </div>
        )}
        <input
          id={id}
          className={`
            block w-full px-3 py-2.5 border rounded-lg shadow-sm 
            bg-primary-light border-primary-dark text-neutral-light
            placeholder-neutral-dark focus:outline-none 
            focus:ring-2 focus:ring-secondary focus:border-secondary 
            sm:text-sm transition-colors duration-200 ease-in-out
            ${Icon ? 'pl-10' : ''}
            ${error ? 'border-error focus:ring-error focus:border-error' : 'border-primary-dark'}
            ${className || ''}
          `}
          {...props}
        />
      </div>
      {error && <p className="mt-1.5 text-xs text-error">{error}</p>}
    </div>
  );
};

export default Input;