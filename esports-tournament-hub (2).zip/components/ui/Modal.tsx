import React, { ReactNode, useEffect, useState } from 'react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl'; // Added 2xl
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children, footer, size = 'md' }) => {
  const [showModal, setShowModal] = useState(isOpen);

  useEffect(() => {
    if (isOpen) {
      setShowModal(true);
      document.body.style.overflow = 'hidden'; // Prevent background scrolling
    } else {
      // Allow animation to complete before unmounting or hiding
      const timer = setTimeout(() => {
        setShowModal(false);
        document.body.style.overflow = 'auto';
      }, 300); // Match animation duration
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  if (!showModal && !isOpen) return null; // Only render if actually open or animating out

  const sizeClasses = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-lg',
    xl: 'max-w-xl',
    '2xl': 'max-w-2xl',
  };
  
  const animationClass = isOpen ? 'animate-modal-in' : 'animate-modal-out';

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center modal-overlay p-4 transition-opacity duration-300 ease-in-out ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
      <div 
        className={`bg-background-paper rounded-xl shadow-2xl w-full ${sizeClasses[size]} overflow-hidden transform ${animationClass}`}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
      >
        <div className="flex items-center justify-between p-5 border-b border-primary-light">
          <h3 id="modal-title" className="text-xl font-semibold text-neutral-light">{title}</h3>
          <button
            onClick={onClose}
            className="text-neutral-dark hover:text-neutral-light transition-colors p-1 rounded-full hover:bg-primary-light"
            aria-label="Close modal"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="p-5 md:p-6 max-h-[75vh] overflow-y-auto">
          {children}
        </div>
        {footer && (
          <div className="p-5 border-t border-primary-light flex justify-end space-x-3">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
};

export default Modal;