

export const APP_NAME = "Esports Tournament Hub"; 
export const CURRENCY_SYMBOL = "₹";

// Routes
export const ROUTE_HOME = "/";
export const ROUTE_LOGIN = "/login";
export const ROUTE_SIGNUP = "/signup";
export const ROUTE_PROFILE = "/profile";
export const ROUTE_TOURNAMENTS = "/tournaments"; // Might not be a separate page, integrated into dashboard

export const ROUTE_ADMIN_DASHBOARD = "/admin";
export const ROUTE_ADMIN_TOURNAMENTS = "/admin/tournaments";
export const ROUTE_ADMIN_TRANSACTIONS = "/admin/transactions";
export const ROUTE_ADMIN_BANK_DETAILS = "/admin/bank-details";
export const ROUTE_ADMIN_USERS = "/admin/users";

export const ROUTE_OWNER_DASHBOARD = "/owner"; // New Owner Route
export const ROUTE_OWNER_USERS = "/owner/users"; // New Owner Route


// LocalStorage Keys
export const LS_AUTH_USER_KEY = "authUser";
export const LS_USERS_KEY = "app_users";
export const LS_TOURNAMENTS_KEY = "app_tournaments";
export const LS_TRANSACTIONS_KEY = "app_transactions";
export const LS_ADMIN_BANK_DETAILS_KEY = "app_admin_bank_details";

// Default admin user
export const DEFAULT_ADMIN_EMAIL = "admin@example.com";
export const DEFAULT_ADMIN_PASSWORD = "adminpassword"; // For simulation only

// Default owner user
export const DEFAULT_OWNER_EMAIL = "owner@example.com";
export const DEFAULT_OWNER_PASSWORD = "ownerpassword"; // For simulation only


// Placeholder image for tournaments
export const DEFAULT_TOURNAMENT_IMAGE = "https://picsum.photos/seed/gametournament/600/400";