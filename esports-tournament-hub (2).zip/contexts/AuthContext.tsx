
import React, { createContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { User, AuthContextType } from '../types';
import * as authService from '../services/authService';
import { LS_AUTH_USER_KEY } from '../constants';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [isOwner, setIsOwner] = useState<boolean>(false); // Added isOwner state
  const [loading, setLoading] = useState<boolean>(true);

  const performSetCurrentUser = (user: User | null) => {
    setCurrentUser(user);
    setIsAdmin(user?.role === 'admin');
    setIsOwner(user?.role === 'owner'); // Set isOwner
    if (user) {
      localStorage.setItem(LS_AUTH_USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(LS_AUTH_USER_KEY);
    }
  };

  useEffect(() => {
    const storedUserJson = localStorage.getItem(LS_AUTH_USER_KEY);
    if (storedUserJson) {
      try {
        const user: User = JSON.parse(storedUserJson);
        performSetCurrentUser(user); // Use unified function
      } catch (e) {
        console.error("Failed to parse stored user:", e);
        localStorage.removeItem(LS_AUTH_USER_KEY);
      }
    }
    setLoading(false);
  }, []);

  const login = useCallback(async (email: string, password: string): Promise<User | null> => {
    setLoading(true);
    try {
      const user = await authService.login(email, password);
      performSetCurrentUser(user);
      return user;
    } catch (error) {
      console.error("Login failed:", error);
      performSetCurrentUser(null); 
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  const signup = useCallback(async (username:string, email: string, mobileNumber: string, password: string): Promise<User | null> => {
    setLoading(true);
    try {
      const user = await authService.signup(username, email, mobileNumber, password);
      performSetCurrentUser(user); 
      return user;
    } catch (error) {
      console.error("Signup failed:", error);
      performSetCurrentUser(null);
      throw error; 
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    setLoading(true);
    await authService.logout();
    performSetCurrentUser(null);
    setLoading(false);
  }, []);
  
  const refreshCurrentUser = useCallback(async () => {
    setLoading(true);
    const storedUserJson = localStorage.getItem(LS_AUTH_USER_KEY);
    if (storedUserJson) {
      try {
        const storedUser: User = JSON.parse(storedUserJson);
        const latestUser = await authService.getUserById(storedUser.id); 
        if (latestUser) {
          performSetCurrentUser(latestUser);
        } else { 
          await logout(); 
        }
      } catch (e) {
        console.error("Failed to refresh user:", e);
        await logout(); 
      }
    } else {
      performSetCurrentUser(null);
    }
    setLoading(false);
  }, [logout]);


  useEffect(() => {
    const handleStorageChange = (event: StorageEvent) => {
      if (event.key === LS_AUTH_USER_KEY) {
        refreshCurrentUser();
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [refreshCurrentUser]);


  return (
    <AuthContext.Provider value={{ currentUser, isAdmin, isOwner, loading, login, signup, logout, refreshCurrentUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;