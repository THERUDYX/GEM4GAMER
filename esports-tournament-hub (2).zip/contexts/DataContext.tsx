
import React, { createContext, useState, ReactNode, useCallback, useEffect } from 'react';
import { Tournament, Transaction, AdminBankDetails, DataContextType, TournamentStatus, TransactionStatus, UserBankDetails, User } from '../types';
import * as tournamentService from '../services/tournamentService';
import * as transactionService from '../services/transactionService';
import * as adminService from '../services/adminService';
import * as authService from '../services/authService'; 
import { useAuth } from '../hooks/useAuth';

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { currentUser, refreshCurrentUser } = useAuth(); 
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [adminBankDetails, setAdminBankDetails] = useState<AdminBankDetails | null>(null);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [isLoadingData, setIsLoadingData] = useState<boolean>(false);

  const fetchTournaments = useCallback(async () => {
    setIsLoadingData(true);
    const fetchedTournaments = await tournamentService.getAllTournaments();
    setTournaments(fetchedTournaments);
    setIsLoadingData(false);
  }, []);

  const createTournament = useCallback(async (tournamentData: Omit<Tournament, 'id' | 'status' | 'participants'>) => {
    setIsLoadingData(true);
    const newTournament = await tournamentService.createTournament(tournamentData);
    if (newTournament) {
      setTournaments(prev => [...prev, newTournament].sort((a,b) => new Date(b.scheduleDate).getTime() - new Date(a.scheduleDate).getTime()));
    }
    setIsLoadingData(false);
    return newTournament;
  }, []);

  const updateTournament = useCallback(async (tournamentId: string, updates: Partial<Tournament>) => {
    setIsLoadingData(true);
    const updatedTournament = await tournamentService.updateTournament(tournamentId, updates);
    if (updatedTournament) {
      setTournaments(prev => prev.map(t => t.id === tournamentId ? updatedTournament : t).sort((a,b) => new Date(b.scheduleDate).getTime() - new Date(a.scheduleDate).getTime()));
    }
    setIsLoadingData(false);
    return updatedTournament;
  }, []);
  
  const fetchTransactions = useCallback(async (userId?: string) => {
    setIsLoadingData(true);
    const fetchedTransactions = userId 
      ? await transactionService.getUserTransactions(userId)
      : await transactionService.getAllTransactions(); 
    setTransactions(fetchedTransactions);
    setIsLoadingData(false);
  }, []);

  const joinTournament = useCallback(async (tournamentId: string, userId: string, gameName: string): Promise<boolean> => {
    setIsLoadingData(true);
    let success = false;
    try {
        success = await tournamentService.joinTournament(tournamentId, userId, gameName);
        if (success) {
          await fetchTournaments(); 
          if (currentUser && currentUser.id === userId) { 
             await fetchTransactions(currentUser.id);
             await refreshCurrentUser(); 
          }
        }
    } catch (error) {
        console.error("Error joining tournament:", error);
        throw error; 
    } finally {
        setIsLoadingData(false);
    }
    return success;
  }, [fetchTournaments, currentUser, fetchTransactions, refreshCurrentUser]);

  const submitTournamentResult = useCallback(async (tournamentId: string, userId: string, resultImageUrl: string): Promise<Tournament | null> => {
    setIsLoadingData(true);
    try {
      const updatedTournament = await tournamentService.submitTournamentResult(tournamentId, userId, resultImageUrl);
      if (updatedTournament) {
        setTournaments(prev => prev.map(t => t.id === tournamentId ? updatedTournament : t).sort((a,b) => new Date(b.scheduleDate).getTime() - new Date(a.scheduleDate).getTime()));
      }
      setIsLoadingData(false);
      return updatedTournament;
    } catch (error) {
      setIsLoadingData(false);
      console.error("Error submitting tournament result:", error);
      throw error; 
    }
  }, []);


  const requestDeposit = useCallback(async (userId: string, amount: number, paymentScreenshotUrl: string, utrNumber?: string) => {
    setIsLoadingData(true);
    const newTransaction = await transactionService.requestDeposit(userId, amount, paymentScreenshotUrl, utrNumber);
    if (newTransaction) {
      setTransactions(prev => [...prev, newTransaction].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    }
    setIsLoadingData(false);
    return newTransaction;
  }, []);

  const requestWithdrawal = useCallback(async (userId: string, amount: number, bankDetails: UserBankDetails) => {
    setIsLoadingData(true);
    const newTransaction = await transactionService.requestWithdrawal(userId, amount, bankDetails);
    if (newTransaction) {
       setTransactions(prev => [...prev, newTransaction].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    }
    setIsLoadingData(false);
    return newTransaction;
  }, []); 
  
  const fetchAllUsers = useCallback(async () => {
    setIsLoadingData(true);
    const users = await authService.getAllUsers(); 
    setAllUsers(users);
    setIsLoadingData(false);
  }, []);

  const updateTransactionStatus = useCallback(async (transactionId: string, status: TransactionStatus, adminNotes?: string) => {
    setIsLoadingData(true);
    const updatedTransaction = await transactionService.updateTransactionStatus(transactionId, status, adminNotes);
    if (updatedTransaction) {
      setTransactions(prev => prev.map(tx => tx.id === transactionId ? updatedTransaction : tx));
      if (currentUser && updatedTransaction.userId === currentUser.id && status === TransactionStatus.CONFIRMED) {
        await refreshCurrentUser(); 
      }
      // No need to fetchAllUsers here typically, unless balance updates are not reflecting correctly via refreshCurrentUser
      // await fetchAllUsers(); 
    }
    setIsLoadingData(false);
    return updatedTransaction;
  }, [currentUser, refreshCurrentUser]);

  const grantBonusCredit = useCallback(async (userId: string, amount: number, adminNotes?: string) => {
    setIsLoadingData(true);
    const newTransaction = await transactionService.grantBonusCredit(userId, amount, adminNotes);
    if (newTransaction) {
      setTransactions(prev => [...prev, newTransaction].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
      await fetchAllUsers(); // Refresh all users as an admin/owner action affected a user.
      if (currentUser && newTransaction.userId === currentUser.id) {
         await refreshCurrentUser(); 
      }
    }
    setIsLoadingData(false);
    return newTransaction;
  }, [currentUser, refreshCurrentUser, fetchAllUsers]);

  const ownerUpdateUser = useCallback(async (userId: string, updates: Partial<User>): Promise<User | null> => {
    setIsLoadingData(true);
    try {
      const updatedUser = await authService.ownerUpdateUserUnsafe(userId, updates);
      if (updatedUser) {
        await fetchAllUsers(); // Refresh the list of all users
        if (currentUser && currentUser.id === updatedUser.id) { // If owner edited their own account
          await refreshCurrentUser();
        }
        // If an ID was changed, tournaments and transactions might also need a refresh.
        // For simplicity, we are handling this broadly. In a real app, this would be more granular.
        await fetchTournaments();
        await fetchTransactions(); // Fetch all transactions
      }
      setIsLoadingData(false);
      return updatedUser;
    } catch (error) {
      setIsLoadingData(false);
      console.error("Error updating user (owner):", error);
      throw error;
    }
  }, [currentUser, fetchAllUsers, refreshCurrentUser, fetchTournaments, fetchTransactions]);

  const fetchAdminBankDetails = useCallback(async () => {
    setIsLoadingData(true);
    const details = await adminService.getAdminBankDetails();
    setAdminBankDetails(details);
    setIsLoadingData(false);
  }, []);

  const updateAdminBankDetails = useCallback(async (details: Omit<AdminBankDetails, 'id' | 'lastUpdated'>) => {
    setIsLoadingData(true);
    const updatedDetails = await adminService.updateAdminBankDetails(details);
    if (updatedDetails) {
      setAdminBankDetails(updatedDetails);
    }
    setIsLoadingData(false);
    return updatedDetails;
  }, []);

  useEffect(() => {
    fetchTournaments();
    fetchAdminBankDetails();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); 

  return (
    <DataContext.Provider value={{
      tournaments, transactions, adminBankDetails, allUsers,
      fetchTournaments, createTournament, updateTournament, joinTournament, submitTournamentResult,
      fetchTransactions, requestDeposit, requestWithdrawal, updateTransactionStatus, grantBonusCredit,
      fetchAdminBankDetails, updateAdminBankDetails, fetchAllUsers, ownerUpdateUser, // Added ownerUpdateUser
      isLoadingData
    }}>
      {children}
    </DataContext.Provider>
  );
};

export default DataContext;