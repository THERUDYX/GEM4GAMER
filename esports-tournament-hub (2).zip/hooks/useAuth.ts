
import { useContext } from 'react';
import AuthContext from '../contexts/AuthContext';
import { AuthContextType } from '../types';

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  // Ensure all properties are returned, including isOwner
  return {
    currentUser: context.currentUser,
    isAdmin: context.isAdmin,
    isOwner: context.isOwner,
    loading: context.loading,
    login: context.login,
    signup: context.signup,
    logout: context.logout,
    refreshCurrentUser: context.refreshCurrentUser,
  };
};