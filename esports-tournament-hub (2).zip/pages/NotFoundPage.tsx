

import React from 'react';
import { Link } from 'react-router-dom';
import PageContainer from '../components/layout/PageContainer';
import Button from '../components/ui/Button';
import { ROUTE_HOME } from '../constants';
// import { useLanguage } from '../hooks/useLanguage'; // Removed useLanguage
import LoadingSpinner from '../components/ui/LoadingSpinner';

const NotFoundPage: React.FC = () => {
  // const { t, translationsLoading } = useLanguage(); // Removed useLanguage

  // if (translationsLoading) { // Removed translationsLoading check
  //     return <PageContainer title={"Loading..."}><LoadingSpinner text={"Loading..."} /></PageContainer>;
  // }

  return (
    <PageContainer title="Oops! Page Not Found">
      <div className="text-center">
        <h1 className="text-9xl font-bold text-secondary">404</h1>
        <p className="text-2xl text-neutral-light mt-4 mb-8">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <Link to={ROUTE_HOME}>
            <Button variant="primary" size="lg">
                Go to Homepage
            </Button>
        </Link>
      </div>
    </PageContainer>
  );
};

export default NotFoundPage;