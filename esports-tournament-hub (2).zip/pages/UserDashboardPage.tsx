

import React, { useState, useEffect } from 'react';
import { Tournament, Transaction, AlertMessage, TournamentStatus } from '../types';
import { useAuth } from '../hooks/useAuth';
import { useData } from '../hooks/useData';
// import { useLanguage } from '../hooks/useLanguage'; // Removed useLanguage
import PageContainer from '../components/layout/PageContainer';
import TournamentList from '../components/tournament/TournamentList';
import TransactionList from '../components/transaction/TransactionList';
import Button from '../components/ui/Button';
import DepositModal from '../components/transaction/DepositModal';
import WithdrawModal from '../components/transaction/WithdrawModal';
import TournamentDetailsModal from '../components/tournament/TournamentDetailsModal';
import JoinTournamentModal from '../components/tournament/JoinTournamentModal';
import Card from '../components/ui/Card';
import { formatCurrency } from '../utils/helpers';
import Alert from '../components/ui/Alert';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import { CURRENCY_SYMBOL } from '../constants';

const UserDashboardPage: React.FC = () => {
  const { currentUser } = useAuth();
  const { 
    tournaments, 
    transactions: allTransactions, 
    fetchTournaments, 
    fetchTransactions, 
    isLoadingData 
  } = useData();
  // const { t, language, translationsLoading } = useLanguage(); // Removed useLanguage
  
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
  const [selectedTournamentForDetails, setSelectedTournamentForDetails] = useState<Tournament | null>(null);
  const [selectedTournamentForJoin, setSelectedTournamentForJoin] = useState<Tournament | null>(null);
  const [isJoinModalOpen, setIsJoinModalOpen] = useState(false);
  const [userTransactions, setUserTransactions] = useState<Transaction[]>([]);
  const [alertInfo, setAlertInfo] = useState<AlertMessage | null>(null);
  const [activeJoinedTournamentsCount, setActiveJoinedTournamentsCount] = useState(0);

  useEffect(() => {
    fetchTournaments();
    if (currentUser) {
      fetchTransactions(currentUser.id);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUser]); 

  useEffect(() => {
    if (currentUser) {
      setUserTransactions(allTransactions.filter(tx => tx.userId === currentUser.id));
      
      const activeCount = tournaments.filter(t =>
        currentUser.joinedTournamentIds.includes(t.id) &&
        (t.status === TournamentStatus.UPCOMING || t.status === TournamentStatus.ONGOING)
      ).length;
      setActiveJoinedTournamentsCount(activeCount);

    } else {
      setUserTransactions([]);
      setActiveJoinedTournamentsCount(0);
    }
  }, [allTransactions, currentUser, tournaments]);

  const handleOpenJoinModal = (tournamentId: string) => {
    setAlertInfo(null);
    if (!currentUser) {
      setAlertInfo({ id: 'joinErrNoUser', type: 'error', message: "You must be logged in to join a tournament." });
      return;
    }
    const tournamentToJoin = tournaments.find(t => t.id === tournamentId);
    if (!tournamentToJoin) return;

    if (tournamentToJoin.participants.length >= tournamentToJoin.maxParticipants) {
      setAlertInfo({ id: 'joinErrFull', type: 'error', message: `${tournamentToJoin.name} is full.` });
      return;
    }
    setSelectedTournamentForJoin(tournamentToJoin);
    setIsJoinModalOpen(true);
  };

  const handleJoinSuccess = () => {
    fetchTournaments();
    if (currentUser) {
        fetchTransactions(currentUser.id);
    }
  };

  const handleViewTournamentDetails = (tournament: Tournament) => {
    setSelectedTournamentForDetails(tournament);
  };

  // if (translationsLoading) { // Removed translationsLoading check
  //   return <PageContainer title={"Loading..."}><LoadingSpinner text={"Loading..."} /></PageContainer>;
  // }

  if (!currentUser) {
    return <PageContainer title={`Welcome!` }><p>Please log in to view your dashboard.</p></PageContainer>;
  }
  const displayName = currentUser.username || currentUser.email;
  const pageTitle = `Welcome, ${displayName}!`;

  return (
    <PageContainer title={pageTitle}>
      {alertInfo && <Alert alert={alertInfo} onDismiss={() => setAlertInfo(null)} />}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="md:col-span-1">
          <h2 className="text-xl font-semibold text-secondary mb-2">Your Wallet</h2>
          <p className="text-3xl font-bold text-neutral-light mb-4">{formatCurrency(currentUser.balance, CURRENCY_SYMBOL)}</p>
          <div className="flex space-x-2">
            <Button onClick={() => setIsDepositModalOpen(true)} variant="primary" className="flex-1">Deposit</Button>
            <Button onClick={() => setIsWithdrawModalOpen(true)} variant="secondary" className="flex-1">Withdraw</Button>
          </div>
        </Card>
        <Card className="md:col-span-2">
           <h2 className="text-xl font-semibold text-secondary mb-2">Quick Stats</h2>
           <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-neutral-default">Total Joined</p>
                <p className="text-2xl font-bold text-neutral-light">{currentUser.joinedTournamentIds.length}</p>
              </div>
              <div>
                <p className="text-sm text-neutral-default">Active Joined</p>
                <p className="text-2xl font-bold text-neutral-light">{activeJoinedTournamentsCount}</p>
              </div>
              <div>
                <p className="text-sm text-neutral-default">Pending Transactions</p>
                <p className="text-2xl font-bold text-neutral-light">{userTransactions.filter(tx => tx.status === 'Pending').length}</p>
              </div>
           </div>
        </Card>
      </div>

      <div className="mb-8">
        <h2 className="text-2xl font-semibold text-secondary mb-4">Available Tournaments</h2>
        <TournamentList
          tournaments={tournaments.filter(t => t.status === TournamentStatus.UPCOMING || t.status === TournamentStatus.ONGOING)}
          onJoinTournament={handleOpenJoinModal}
          onViewTournamentDetails={handleViewTournamentDetails}
          isLoading={isLoadingData && tournaments.length === 0}
          userId={currentUser.id}
          isUserLoggedIn={!!currentUser}
          emptyStateMessage="No tournaments available at the moment. Check back soon!"
        />
      </div>

      <div>
        <TransactionList 
          transactions={userTransactions} 
          isLoading={isLoadingData && userTransactions.length === 0}
          title="Your Recent Transactions"
        />
      </div>

      <DepositModal isOpen={isDepositModalOpen} onClose={() => setIsDepositModalOpen(false)} />
      <WithdrawModal isOpen={isWithdrawModalOpen} onClose={() => setIsWithdrawModalOpen(false)} />
      {selectedTournamentForDetails && (
        <TournamentDetailsModal
          isOpen={!!selectedTournamentForDetails}
          onClose={() => setSelectedTournamentForDetails(null)}
          tournament={selectedTournamentForDetails}
        />
      )}
      {selectedTournamentForJoin && (
        <JoinTournamentModal
          isOpen={isJoinModalOpen}
          onClose={() => setIsJoinModalOpen(false)}
          tournament={selectedTournamentForJoin}
          onJoinSuccess={handleJoinSuccess}
        />
      )}
    </PageContainer>
  );
};

export default UserDashboardPage;