

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage
import PageContainer from '../../components/layout/PageContainer';
import Card from '../../components/ui/Card';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import { UserBankDetails, Tournament, AlertMessage, TournamentStatus } from '../../types';
import * as userService from '../../services/authService'; 
import TournamentList from '../../components/tournament/TournamentList';
import TournamentDetailsModal from '../../components/tournament/TournamentDetailsModal';
import SubmitResultModal from '../../components/tournament/SubmitResultModal';
import { formatCurrency } from '../../utils/helpers';
import { ROUTE_HOME, CURRENCY_SYMBOL } from '../../constants';
import Alert from '../../components/ui/Alert';
import LoadingSpinner from '../../components/ui/LoadingSpinner';

const UserProfilePage: React.FC = () => {
  const { currentUser, refreshCurrentUser } = useAuth();
  const { tournaments, fetchTournaments } = useData(); 
  // const { t, language, translationsLoading } = useLanguage(); // Removed useLanguage
  const navigate = useNavigate();

  const [bankDetails, setBankDetails] = useState<UserBankDetails>({
    accountHolderName: '',
    accountNumber: '',
    bankName: '',
    ifscCode: '',
  });
  const [isEditingBankDetails, setIsEditingBankDetails] = useState(false);
  const [alert, setAlert] = useState<AlertMessage | null>(null);
  const [userJoinedTournaments, setUserJoinedTournaments] = useState<Tournament[]>([]);
  const [selectedTournamentForDetails, setSelectedTournamentForDetails] = useState<Tournament | null>(null);
  const [selectedTournamentForResults, setSelectedTournamentForResults] = useState<Tournament | null>(null);

  useEffect(() => {
    if (currentUser) {
      setBankDetails(currentUser.bankDetails || { accountHolderName: '', accountNumber: '', bankName: '', ifscCode: '' });
      fetchTournaments(); 
    } else {
      navigate(ROUTE_HOME); 
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUser, navigate]);

  useEffect(() => {
    if (currentUser && tournaments.length > 0) {
      const joined = tournaments.filter(t => currentUser.joinedTournamentIds.includes(t.id));
      setUserJoinedTournaments(joined);
    } else {
      setUserJoinedTournaments([]);
    }
  }, [currentUser, tournaments]);


  const handleBankDetailsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setBankDetails(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSaveBankDetails = async () => {
    setAlert(null);
    if (!currentUser) return;
    if (Object.values(bankDetails).some(val => val.trim() === '')) {
      setAlert({ id: 'bankError', type: 'error', message: "All bank detail fields are required." });
      return;
    }
    try {
      await userService.updateUser(currentUser.id, { bankDetails });
      await refreshCurrentUser(); 
      setAlert({ id: 'bankSuccess', type: 'success', message: "Bank details updated successfully!" });
      setIsEditingBankDetails(false);
    } catch (error) {
      setAlert({ id: 'bankFail', type: 'error', message: "Failed to update bank details." });
    }
  };

  const handleViewTournamentDetails = (tournament: Tournament) => {
    setSelectedTournamentForDetails(tournament);
  };
  
  const handleOpenSubmitResultModal = (tournament: Tournament) => {
    const userParticipation = tournament.participants.find(p => p.userId === currentUser?.id);
    if (tournament.status !== TournamentStatus.COMPLETED) {
      setAlert({ id: 'resultNotCompleted', type: 'warning', message: "Results can only be submitted for completed tournaments." });
      return;
    }
    if (userParticipation?.resultImageUrl) {
      setAlert({ id: 'resultAlreadySubmitted', type: 'info', message: "You have already submitted your result for this tournament." });
      return;
    }
    setSelectedTournamentForResults(tournament);
  };
  
  const handleResultSubmitted = () => {
    fetchTournaments();
  };


  if (/*!translationsLoading &&*/ !currentUser) { // Removed translationsLoading
    return <PageContainer title={"Loading profile..."}><LoadingSpinner text={"Loading profile..."} /></PageContainer>;
  }
  
  const pageTitle = `${currentUser.username}'s Profile`;

  const canSubmitResult = (tournament: Tournament): boolean => {
    if (tournament.status !== TournamentStatus.COMPLETED) return false;
    const participation = tournament.participants.find(p => p.userId === currentUser.id);
    return !!participation && !participation.resultImageUrl; 
  };
  
  const hasSubmittedResult = (tournament: Tournament): boolean => {
    const participation = tournament.participants.find(p => p.userId === currentUser.id);
    return !!participation?.resultImageUrl;
  };

  return (
    <PageContainer title={pageTitle}>
      {alert && <Alert alert={alert} onDismiss={() => setAlert(null)} />}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1 space-y-6">
          <Card title="Account Information">
            <p><strong className="text-neutral-default">Username:</strong> {currentUser.username}</p>
            <p><strong className="text-neutral-default">Email:</strong> {currentUser.email}</p>
            <p><strong className="text-neutral-default">Role:</strong> <span className="capitalize">{currentUser.role === 'admin' ? "Admin" : "User"}</span></p>
          </Card>
          <Card title="Wallet">
            <p className="text-3xl font-bold text-secondary mb-3">{formatCurrency(currentUser.balance, CURRENCY_SYMBOL)}</p>
            <p className="text-xs text-neutral-dark">Manage deposits and withdrawals from the dashboard.</p>
          </Card>
        </div>

        <div className="md:col-span-2">
          <Card title="Bank Details for Withdrawals">
            {isEditingBankDetails ? (
              <form className="space-y-4">
                <Input label="Account Holder Name" name="accountHolderName" value={bankDetails.accountHolderName} onChange={handleBankDetailsChange} required />
                <Input label="Account Number" name="accountNumber" value={bankDetails.accountNumber} onChange={handleBankDetailsChange} required />
                <Input label="Bank Name" name="bankName" value={bankDetails.bankName} onChange={handleBankDetailsChange} required />
                <Input label="IFSC Code" name="ifscCode" value={bankDetails.ifscCode} onChange={handleBankDetailsChange} required />
                <div className="flex space-x-2">
                  <Button onClick={handleSaveBankDetails} variant="primary">Save</Button>
                  <Button onClick={() => { setIsEditingBankDetails(false); setBankDetails(currentUser.bankDetails || { accountHolderName: '', accountNumber: '', bankName: '', ifscCode: '' }); }} variant="ghost">Cancel</Button>
                </div>
              </form>
            ) : (
              <div className="space-y-2">
                {currentUser.bankDetails ? (
                  <>
                    <p><strong className="text-neutral-default">Account Holder Name:</strong> {currentUser.bankDetails.accountHolderName}</p>
                    <p><strong className="text-neutral-default">Account Number:</strong> {currentUser.bankDetails.accountNumber}</p>
                    <p><strong className="text-neutral-default">Bank Name:</strong> {currentUser.bankDetails.bankName}</p>
                    <p><strong className="text-neutral-default">IFSC Code:</strong> {currentUser.bankDetails.ifscCode}</p>
                  </>
                ) : (
                  <p className="text-neutral-dark">No bank details saved yet. Please add them to enable withdrawals.</p>
                )}
                <Button onClick={() => setIsEditingBankDetails(true)} variant="secondary" size="sm" className="mt-3">
                  {currentUser.bankDetails ? "Edit Bank Details" : "Add Bank Details"}
                </Button>
              </div>
            )}
          </Card>
        </div>
      </div>

      <div className="mt-10">
        <h2 className="text-2xl font-semibold text-secondary mb-5">My Tournaments</h2>
        <TournamentList
          tournaments={userJoinedTournaments}
          onViewTournamentDetails={handleViewTournamentDetails}
          isLoading={tournaments.length === 0 && userJoinedTournaments.length > 0}
          userId={currentUser.id}
          isUserLoggedIn={!!currentUser}
          emptyStateMessage="You haven't joined any tournaments yet."
          emptyStateIcon={() => (
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16 text-primary-light mb-4">
              <path strokeLinecap="round" strokeLinejoin="round" d="M11.412 15.655 9.75 21.75l3.745-4.032m1.005-1.077a2.25 2.25 0 1 0-3.182-3.182 2.25 2.25 0 0 0 3.182 3.182ZM15.75 12a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0Z" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M21.752 15.002A9.72 9.72 0 0 1 18 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 0 0 3 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 0 0 9.002-5.998Z" />
            </svg>
          )}
        />
        {userJoinedTournaments.length > 0 && (
          <div className="mt-6 space-y-4">
             {userJoinedTournaments.filter(t => t.status === TournamentStatus.COMPLETED).map(tournament => (
                 <Card key={`submit-${tournament.id}`} title={`Result for: ${tournament.name}`} className="bg-primary-light border-l-4 border-yellow-500">
                     <div className="flex justify-between items-center">
                         <div>
                            <p className="text-sm text-neutral-default">Status: {tournament.status === TournamentStatus.COMPLETED ? "Completed" : tournament.status}</p>
                            {hasSubmittedResult(tournament) && <p className="text-sm text-success font-semibold">Result Submitted!</p>}
                         </div>
                        {canSubmitResult(tournament) && (
                           <Button 
                             onClick={() => handleOpenSubmitResultModal(tournament)} 
                             variant="primary"
                           >
                             Submit Result
                           </Button>
                         )}
                         {!canSubmitResult(tournament) && hasSubmittedResult(tournament) && (
                            <span className="text-sm text-green-400 italic">Submission recorded.</span>
                         )}
                         {tournament.status !== TournamentStatus.COMPLETED && (
                             <span className="text-sm text-neutral-dark italic">Results can be submitted once the tournament is completed.</span>
                         )}
                     </div>
                 </Card>
             ))}
          </div>
        )}
      </div>

      {selectedTournamentForDetails && (
        <TournamentDetailsModal
          isOpen={!!selectedTournamentForDetails}
          onClose={() => setSelectedTournamentForDetails(null)}
          tournament={selectedTournamentForDetails}
        />
      )}
      {selectedTournamentForResults && (
        <SubmitResultModal
          isOpen={!!selectedTournamentForResults}
          onClose={() => setSelectedTournamentForResults(null)}
          tournament={selectedTournamentForResults}
          onResultSubmitted={handleResultSubmitted}
        />
      )}

    </PageContainer>
  );
};

export default UserProfilePage;