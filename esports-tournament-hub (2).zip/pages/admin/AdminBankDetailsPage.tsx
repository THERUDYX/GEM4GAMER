

import React, { useState, useEffect } from 'react';
import { useData } from '../../hooks/useData';
import { AdminBankDetails, AlertMessage } from '../../types';
import PageContainer from '../../components/layout/PageContainer';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Card from '../../components/ui/Card';
import LoadingSpinner from '../../components/ui/LoadingSpinner';
import Alert from '../../components/ui/Alert';

const AdminBankDetailsPage: React.FC = () => {
  const { adminBankDetails, updateAdminBankDetails, fetchAdminBankDetails, isLoadingData } = useData();
  const [formData, setFormData] = useState<Partial<AdminBankDetails>>({});
  const [qrPreview, setQrPreview] = useState<string | null | undefined>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [alert, setAlert] = useState<AlertMessage | null>(null);

  useEffect(() => {
    fetchAdminBankDetails();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (adminBankDetails) {
      setFormData(adminBankDetails);
      setQrPreview(adminBankDetails.qrCodeImageUrl);
    }
  }, [adminBankDetails]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleQrCodeFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!['image/jpeg', 'image/png', 'image/gif'].includes(file.type)) {
        setAlert({ id: 'fileTypeError', type: 'error', message: "Invalid file type. Please upload a JPG, PNG, or GIF image." });
        event.target.value = '';
        return;
      }
      if (file.size > 1 * 1024 * 1024) { // Max 1MB for QR code
        setAlert({ id: 'fileSizeError', type: 'error', message: "File is too large. Maximum size is 1MB." });
        event.target.value = '';
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setFormData(prev => ({ ...prev, qrCodeImageUrl: base64String }));
        setQrPreview(base64String);
      };
      reader.readAsDataURL(file);
      setAlert(null);
    }
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlert(null);
    if (!formData.accountHolderName || !formData.accountNumber || !formData.bankName || !formData.ifscCode) {
        setAlert({ id: 'bankDetailsError', type: 'error', message: 'All fields (except UPI ID and QR Code) are required.' });
        return;
    }
    try {
      const updateData = {
        accountHolderName: formData.accountHolderName!,
        accountNumber: formData.accountNumber!,
        bankName: formData.bankName!,
        ifscCode: formData.ifscCode!,
        upiId: formData.upiId || undefined,
        qrCodeImageUrl: formData.qrCodeImageUrl || undefined,
      };
      await updateAdminBankDetails(updateData);
      setAlert({ id: 'bankDetailsSuccess', type: 'success', message: 'Bank details updated successfully!' });
      setIsEditing(false);
      fetchAdminBankDetails(); 
    } catch (error) {
      console.error("Error updating bank details:", error);
      setAlert({ id: 'bankDetailsFail', type: 'error', message: 'Failed to update bank details.' });
    }
  };

  if (isLoadingData && !adminBankDetails) {
    return <PageContainer title="Deposit Bank Details"><LoadingSpinner text="Loading bank details..." /></PageContainer>;
  }

  if (!adminBankDetails && !isLoadingData) {
     return <PageContainer title="Deposit Bank Details"><p className="text-error">Could not load admin bank details. Please try again later or contact support.</p></PageContainer>;
  }


  return (
    <PageContainer title="Deposit Bank Details">
      {alert && <Alert alert={alert} onDismiss={() => setAlert(null)} />}
      <Card>
        {!isEditing && adminBankDetails ? (
          <div className="space-y-3">
            <p><strong className="text-neutral-default">Account Holder:</strong> {adminBankDetails.accountHolderName}</p>
            <p><strong className="text-neutral-default">Account Number:</strong> {adminBankDetails.accountNumber}</p>
            <p><strong className="text-neutral-default">Bank Name:</strong> {adminBankDetails.bankName}</p>
            <p><strong className="text-neutral-default">IFSC Code:</strong> {adminBankDetails.ifscCode}</p>
            {adminBankDetails.upiId && <p><strong className="text-neutral-default">UPI ID:</strong> {adminBankDetails.upiId}</p>}
            {adminBankDetails.qrCodeImageUrl && (
                <div className="mt-3">
                    <p><strong className="text-neutral-default">QR Code:</strong></p>
                    <img src={adminBankDetails.qrCodeImageUrl} alt="Payment QR Code" className="max-w-xs h-auto rounded-md border border-primary-dark mt-1" />
                </div>
            )}
            <p className="text-xs text-neutral-dark mt-3">Last Updated: {new Date(adminBankDetails.lastUpdated).toLocaleString()}</p>
            <Button onClick={() => setIsEditing(true)} variant="primary" className="mt-4">Edit Details</Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            <Input label="Account Holder Name" name="accountHolderName" value={formData.accountHolderName || ''} onChange={handleInputChange} required />
            <Input label="Account Number" name="accountNumber" value={formData.accountNumber || ''} onChange={handleInputChange} required />
            <Input label="Bank Name" name="bankName" value={formData.bankName || ''} onChange={handleInputChange} required />
            <Input label="IFSC Code" name="ifscCode" value={formData.ifscCode || ''} onChange={handleInputChange} required />
            <Input label="UPI ID (Optional)" name="upiId" value={formData.upiId || ''} onChange={handleInputChange} />
            <div>
              <label htmlFor="qrCodeImage" className="block text-sm font-medium text-neutral-light mb-1.5">
                QR Code Image (Optional, Max 1MB)
              </label>
              <input
                id="qrCodeImage"
                name="qrCodeImage"
                type="file"
                accept="image/png, image/jpeg, image/gif"
                onChange={handleQrCodeFileChange}
                className="block w-full text-sm text-neutral-light file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-secondary file:text-primary-dark hover:file:bg-secondary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-secondary focus:ring-offset-background-paper"
              />
              {qrPreview && (
                <div className="mt-3">
                  <img src={qrPreview} alt="QR Code Preview" className="max-w-xs h-auto rounded-lg border-2 border-primary-dark shadow-sm object-contain" />
                </div>
              )}
            </div>
            <div className="flex space-x-2 pt-3 border-t border-primary-light">
              <Button type="submit" isLoading={isLoadingData} variant="primary">Save Changes</Button>
              {adminBankDetails && <Button type="button" onClick={() => { setIsEditing(false); setFormData(adminBankDetails); setQrPreview(adminBankDetails.qrCodeImageUrl); }} variant="ghost">Cancel</Button>}
            </div>
          </form>
        )}
      </Card>
    </PageContainer>
  );
};

export default AdminBankDetailsPage;