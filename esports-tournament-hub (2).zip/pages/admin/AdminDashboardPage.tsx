import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useData } from '../../hooks/useData';
import PageContainer from '../../components/layout/PageContainer';
import Card from '../../components/ui/Card';
import { ROUTE_ADMIN_TOURNAMENTS, ROUTE_ADMIN_TRANSACTIONS, ROUTE_ADMIN_BANK_DETAILS, ROUTE_ADMIN_USERS } from '../../constants';
import LoadingSpinner from '../../components/ui/LoadingSpinner';
import { TournamentStatus, TransactionStatus } from '../../types';

const AdminDashboardPage: React.FC = () => {
  const { currentUser, isAdmin } = useAuth();
  const { tournaments, transactions, allUsers, fetchTournaments, fetchTransactions, fetchAllUsers, isLoadingData } = useData();

  useEffect(() => {
    // Fetch all data needed for admin dashboard stats
    fetchTournaments();
    fetchTransactions(); // Fetch all transactions for admin
    fetchAllUsers(); // Fetch all users for admin stats
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); 

  if (isLoadingData && (!tournaments.length || !transactions.length || !allUsers.length)) {
      // Show loader if any of the essential data is still loading and not yet available
      const stillLoading = (isLoadingData && (!tournaments.length && !transactions.length && !allUsers.length));
      if (stillLoading) return <PageContainer title="Admin Dashboard"><LoadingSpinner text="Loading admin data..." /></PageContainer>;
  }


  if (!currentUser || !isAdmin) {
    return <PageContainer title="Access Denied"><p>You do not have permission to view this page.</p></PageContainer>;
  }

  const upcomingTournaments = tournaments.filter(t => t.status === TournamentStatus.UPCOMING).length;
  const ongoingTournaments = tournaments.filter(t => t.status === TournamentStatus.ONGOING).length;
  const pendingDeposits = transactions.filter(t => t.type === 'Deposit' && t.status === TransactionStatus.PENDING).length;
  const pendingWithdrawals = transactions.filter(t => t.type === 'Withdrawal' && t.status === TransactionStatus.PENDING).length;
  const totalUsers = allUsers.length;

  const StatCard: React.FC<{title: string, value: string | number, linkTo?: string, linkText?: string, color?: string}> = ({title, value, linkTo, linkText, color = "text-secondary"}) => (
    <Card className="hover:shadow-secondary/50 transition-shadow">
      <h3 className="text-lg font-medium text-neutral-default">{title}</h3>
      <p className={`text-4xl font-bold ${color} mt-1 mb-3`}>{value}</p>
      {linkTo && linkText && <Link to={linkTo} className="text-sm text-accent hover:underline">{linkText}</Link>}
    </Card>
  );

  return (
    <PageContainer title="Admin Dashboard">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 mb-8">
        <StatCard title="Total Users" value={totalUsers} linkTo={ROUTE_ADMIN_USERS} linkText="Manage Users" />
        <StatCard title="Upcoming Tournaments" value={upcomingTournaments} linkTo={ROUTE_ADMIN_TOURNAMENTS} linkText="Manage Tournaments" />
        <StatCard title="Ongoing Tournaments" value={ongoingTournaments} linkTo={ROUTE_ADMIN_TOURNAMENTS} linkText="Manage Tournaments" color="text-green-400"/>
        <StatCard title="Pending Deposits" value={pendingDeposits} linkTo={ROUTE_ADMIN_TRANSACTIONS} linkText="Review Transactions" color="text-yellow-400" />
        <StatCard title="Pending Withdrawals" value={pendingWithdrawals} linkTo={ROUTE_ADMIN_TRANSACTIONS} linkText="Review Transactions" color="text-orange-400" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Link to={ROUTE_ADMIN_USERS} className="block">
          <Card className="text-center hover:bg-primary-light transition-colors py-6">
            <UsersIcon className="w-16 h-16 mx-auto mb-3 text-accent" />
            <h2 className="text-xl font-semibold text-neutral-light">Manage Users</h2>
            <p className="text-sm text-neutral-default">View and manage user accounts.</p>
          </Card>
        </Link>
        <Link to={ROUTE_ADMIN_TOURNAMENTS} className="block">
          <Card className="text-center hover:bg-primary-light transition-colors py-6">
            <TournamentIcon className="w-16 h-16 mx-auto mb-3 text-accent" />
            <h2 className="text-xl font-semibold text-neutral-light">Manage Tournaments</h2>
            <p className="text-sm text-neutral-default">Create, update, and oversee tournaments.</p>
          </Card>
        </Link>
        <Link to={ROUTE_ADMIN_TRANSACTIONS} className="block">
          <Card className="text-center hover:bg-primary-light transition-colors py-6">
            <TransactionIcon className="w-16 h-16 mx-auto mb-3 text-accent" />
            <h2 className="text-xl font-semibold text-neutral-light">Manage Transactions</h2>
            <p className="text-sm text-neutral-default">Approve or decline transactions.</p>
          </Card>
        </Link>
        <Link to={ROUTE_ADMIN_BANK_DETAILS} className="block">
          <Card className="text-center hover:bg-primary-light transition-colors py-6">
            <BankIcon className="w-16 h-16 mx-auto mb-3 text-accent" />
            <h2 className="text-xl font-semibold text-neutral-light">Update Bank Details</h2>
            <p className="text-sm text-neutral-default">Manage deposit bank details.</p>
          </Card>
        </Link>
      </div>
    </PageContainer>
  );
};


const TournamentIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 18.75h-9m9 0a3 3 0 013 3h-15a3 3 0 013-3m9 0v-4.5A3.375 3.375 0 0012.75 9.75H11.25A3.375 3.375 0 007.5 13.125V18.75m9 0h1.5a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v9.75A2.25 2.25 0 004.5 18.75H6M12 9V6.75A3.375 3.375 0 008.625 3.375H7.5A3.375 3.375 0 004.125 6.75V9" />
  </svg>
);
const TransactionIcon: React.FC<{className?: string}> = ({className}) => (
 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
  <path strokeLinecap="round" strokeLinejoin="round" d="M7.5 21L3 16.5m0 0L7.5 12M3 16.5h18M16.5 3L21 7.5m0 0L16.5 12M21 7.5H3" />
</svg>
);
const BankIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21V3m0 18H3.75M12 21h8.25M12 3H3.75M12 3h8.25M3.75 21V10.5A2.25 2.25 0 016 8.25h12A2.25 2.25 0 0120.25 10.5V21M3.75 9V6.75A2.25 2.25 0 016 4.5h12A2.25 2.25 0 0120.25 6.75V9M3.75 9h16.5" />
  </svg>
);
const UsersIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z" />
  </svg>
);


export default AdminDashboardPage;