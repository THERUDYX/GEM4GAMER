

import React, { useState, useEffect } from 'react';
import { useData } from '../../hooks/useData';
import { Tournament, TournamentStatus, AlertMessage, User } from '../../types'; // Added User
import PageContainer from '../../components/layout/PageContainer';
import Button from '../../components/ui/Button';
import Modal from '../../components/ui/Modal';
import Input from '../../components/ui/Input';
import Card from '../../components/ui/Card';
import { formatCurrency, formatDate } from '../../utils/helpers';
import LoadingSpinner from '../../components/ui/LoadingSpinner';
import { DEFAULT_TOURNAMENT_IMAGE, CURRENCY_SYMBOL } from '../../constants';
import Alert from '../../components/ui/Alert';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage

const EmptyStateIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-20 h-20 text-primary-light mx-auto mb-4">
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 18.75h-9m9 0a3 3 0 013 3h-15a3 3 0 013-3m9 0v-4.5A3.375 3.375 0 0012.75 9.75H11.25A3.375 3.375 0 007.5 13.125V18.75m9 0h1.5a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v9.75A2.25 2.25 0 004.5 18.75H6M12 9V6.75A3.375 3.375 0 008.625 3.375H7.5A3.375 3.375 0 004.125 6.75V9" />
  </svg>
);

const AdminTournamentsPage: React.FC = () => {
  const { tournaments, createTournament, updateTournament, fetchTournaments, isLoadingData, allUsers, fetchAllUsers } = useData();
  // const { t, language } = useLanguage(); // Removed useLanguage
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTournament, setEditingTournament] = useState<Tournament | null>(null); // Changed type to Tournament
  const [formData, setFormData] = useState<Partial<Tournament>>({
    name: '', game: '', entryFee: 0, prizePool: 0, scheduleDate: '', imageUrl: DEFAULT_TOURNAMENT_IMAGE, roomId: '', roomPassword: '', status: TournamentStatus.UPCOMING, maxParticipants: 50
  });
  const [imagePreview, setImagePreview] = useState<string | null>(DEFAULT_TOURNAMENT_IMAGE);
  const [alert, setAlert] = useState<AlertMessage | null>(null);

  useEffect(() => {
    fetchTournaments();
    if (!allUsers || allUsers.length === 0) {
        fetchAllUsers();
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleImageFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // Max 2MB
        setAlert({ id: 'fileSizeErrorTournament', type: 'error', message: "File is too large. Max 2MB."});
        setImagePreview(formData.imageUrl || DEFAULT_TOURNAMENT_IMAGE); // Revert to old or default
        event.target.value = ''; // Reset file input
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setFormData(prev => ({ ...prev, imageUrl: base64String }));
        setImagePreview(base64String);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const resetFormAndModal = () => {
    setFormData({ name: '', game: '', entryFee: 0, prizePool: 0, scheduleDate: new Date().toISOString().substring(0, 16), imageUrl: DEFAULT_TOURNAMENT_IMAGE, roomId: '', roomPassword: '', status: TournamentStatus.UPCOMING, maxParticipants: 50 });
    setImagePreview(DEFAULT_TOURNAMENT_IMAGE);
    setEditingTournament(null);
  }

  const openCreateModal = () => {
    setEditingTournament(null);
    resetFormAndModal();
    setIsModalOpen(true);
  };

  const openEditModal = (tournament: Tournament) => {
    setEditingTournament(tournament);
    setFormData({ ...tournament, scheduleDate: new Date(tournament.scheduleDate).toISOString().substring(0, 16) });
    setImagePreview(tournament.imageUrl);
    setIsModalOpen(true);
    if (!allUsers || allUsers.length === 0) {
        fetchAllUsers();
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    const val = (name === 'entryFee' || name === 'prizePool' || name === 'maxParticipants') ? parseFloat(value) : value;
    setFormData(prev => ({ ...prev, [name]: val }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAlert(null);
    
    if (!formData.name || !formData.game || formData.entryFee! < 0 || formData.prizePool! < 0 || !formData.scheduleDate || formData.maxParticipants! <= 0) {
        setAlert({ id: 'formError', type: 'error', message: "Please fill all required fields correctly." });
        return;
    }

    try {
      const dataPayload = {
        name: formData.name!,
        game: formData.game!,
        entryFee: formData.entryFee!,
        prizePool: formData.prizePool!,
        scheduleDate: new Date(formData.scheduleDate!).toISOString(),
        imageUrl: formData.imageUrl || DEFAULT_TOURNAMENT_IMAGE,
        roomId: formData.roomId,
        roomPassword: formData.roomPassword,
        maxParticipants: formData.maxParticipants!,
      };

      if (editingTournament && editingTournament.id) {
        const updateData: Partial<Tournament> = { 
            ...dataPayload, 
            status: formData.status, 
        };
        await updateTournament(editingTournament.id, updateData);
        setAlert({ id: 'updateSuccess', type: 'success', message: "Tournament updated successfully!" });
      } else {
        await createTournament(dataPayload as Omit<Tournament, 'id' | 'status' | 'participants'>);
        setAlert({ id: 'createSuccess', type: 'success', message: "Tournament created successfully!" });
      }
      setIsModalOpen(false);
      fetchTournaments(); 
      resetFormAndModal();
    } catch (error) {
      console.error("Error saving tournament:", error);
      setAlert({ id: 'saveError', type: 'error', message: "Failed to save tournament." });
    }
  };

  const currencySymbol = CURRENCY_SYMBOL;

  return (
    <PageContainer title="Manage Tournaments">
      {alert && <Alert alert={alert} onDismiss={() => setAlert(null)} />}
      <div className="mb-8 flex justify-end">
        <Button onClick={openCreateModal} variant="primary" IconLeft={() => <PlusIcon />}>Create Tournament</Button>
      </div>

      {isLoadingData && tournaments.length === 0 && (!allUsers || allUsers.length === 0) ? (
        <LoadingSpinner text="Loading tournaments..." />
      ) : tournaments.length === 0 ? (
         <div className="text-center text-neutral-default py-16 px-6 bg-background-paper rounded-xl shadow-lg">
           <EmptyStateIcon />
           <p className="text-2xl font-semibold text-neutral-light mt-2">No Tournaments Yet</p>
           <p className="text-neutral-dark mt-2 mb-6">Get started by creating the first tournament for your hub.</p>
           <Button onClick={openCreateModal} variant="secondary" size="lg" IconLeft={() => <PlusIcon />}>
             Create First Tournament
           </Button>
         </div>
      ) : (
        <div className="space-y-6">
          {tournaments.map(tItem => (
            <Card key={tItem.id} className="hover:shadow-secondary/20 transition-all duration-300">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-x-6 gap-y-4 items-center">
                <div className="md:col-span-1">
                  <img src={tItem.imageUrl} alt={tItem.name} className="w-full h-40 object-cover rounded-lg shadow-md"/>
                </div>
                <div className="md:col-span-2 space-y-1">
                  <h3 className="text-xl font-bold text-secondary">{tItem.name} <span className="text-sm text-accent font-medium">({tItem.game})</span></h3>
                  <p className="text-sm text-neutral-default">Status: <span className={`font-semibold ${
                      tItem.status === TournamentStatus.UPCOMING ? 'text-yellow-400' :
                      tItem.status === TournamentStatus.ONGOING ? 'text-green-400' : 'text-gray-400'
                    }`}>{tItem.status}</span>
                  </p>
                  <p className="text-sm text-neutral-default">Date: {formatDate(tItem.scheduleDate)}</p>
                  <p className="text-sm text-neutral-default">Entry: {formatCurrency(tItem.entryFee, currencySymbol)} | Prize: {formatCurrency(tItem.prizePool, currencySymbol)}</p>
                  <p className="text-sm text-neutral-default">Spots: <span className="font-semibold">{tItem.participants.length} / {tItem.maxParticipants}</span></p>
                   {tItem.roomId && <p className="text-xs text-neutral-dark">Room ID: {tItem.roomId}</p>}
                   {tItem.roomPassword && <p className="text-xs text-neutral-dark">Password: ******</p>}
                </div>
                <div className="md:col-span-1 flex flex-col md:flex-row md:items-center md:justify-end space-y-2 md:space-y-0 md:space-x-2">
                  <Button onClick={() => openEditModal(tItem)} variant="outline" size="sm" className="w-full md:w-auto" IconLeft={() => <EditIcon />}>Edit / View Details</Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal isOpen={isModalOpen} onClose={() => {setIsModalOpen(false); resetFormAndModal();}} title={editingTournament ? "Edit Tournament" : "Create New Tournament"} size="2xl">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6">
            <div className="space-y-6">
              <Input label="Tournament Name" name="name" value={formData.name || ''} onChange={handleInputChange} required />
              <Input label="Game" name="game" value={formData.game || ''} onChange={handleInputChange} required />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <Input label={`Entry Fee (${currencySymbol})`} name="entryFee" type="number" value={String(formData.entryFee || 0)} onChange={handleInputChange} required min="0" />
                <Input label={`Prize Pool (${currencySymbol})`} name="prizePool" type="number" value={String(formData.prizePool || 0)} onChange={handleInputChange} required min="0" />
              </div>
              <Input label="Max Participants" name="maxParticipants" type="number" value={String(formData.maxParticipants || 50)} onChange={handleInputChange} required min="1" />
              <Input label="Schedule Date & Time" name="scheduleDate" type="datetime-local" value={formData.scheduleDate || ''} onChange={handleInputChange} required />
              <Input label="Room ID (Optional)" name="roomId" value={formData.roomId || ''} onChange={handleInputChange} />
              <Input label="Room Password (Optional)" name="roomPassword" type="text" value={formData.roomPassword || ''} onChange={handleInputChange} />
            </div>
            <div className="space-y-6">
              <div>
                <label htmlFor="tournament-image" className="block text-sm font-medium text-neutral-light mb-1.5">
                  Tournament Image (Optional)
                </label>
                <input
                  id="tournament-image"
                  name="tournament-image"
                  type="file"
                  accept="image/png, image/jpeg"
                  onChange={handleImageFileChange}
                  className="block w-full text-sm text-neutral-light file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-secondary file:text-primary-dark hover:file:bg-secondary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-secondary focus:ring-offset-background-paper"
                />
                {imagePreview && (
                  <div className="mt-3">
                    <img src={imagePreview} alt="Tournament image preview" className="max-h-40 rounded-lg border-2 border-primary-dark shadow-sm object-contain" />
                  </div>
                )}
              </div>
              {editingTournament && (
                <div>
                    <label htmlFor="status" className="block text-sm font-medium text-neutral-light mb-1.5">Status</label>
                    <select 
                        name="status" 
                        id="status"
                        value={formData.status} 
                        onChange={handleInputChange}
                        className="block w-full px-3 py-2.5 border rounded-lg shadow-sm bg-primary-light border-primary-dark text-neutral-light placeholder-neutral-dark focus:outline-none focus:ring-2 focus:ring-secondary focus:border-secondary sm:text-sm"
                    >
                        {Object.values(TournamentStatus).map(status => (
                            <option key={status} value={status}>{status}</option>
                        ))}
                    </select>
                </div>
              )}
            </div>
          </div>
          
          {editingTournament && editingTournament.participants && editingTournament.participants.length > 0 && (
            <div className="mt-6 pt-4 border-t border-primary-light">
              <h4 className="text-lg font-semibold text-secondary mb-3">Participants ({editingTournament.participants.length})</h4>
              {isLoadingData && (!allUsers || allUsers.length === 0) ? <LoadingSpinner text="Loading participant details..."/> : (
              <div className="max-h-[300px] overflow-y-auto space-y-3 pr-2 bg-primary-dark/30 p-3 rounded-lg border border-primary-light/50">
                {editingTournament.participants.map(participant => {
                  const user = allUsers.find(u => u.id === participant.userId);
                  return (
                    <div key={participant.userId} className="p-3 bg-background-paper rounded-md shadow-sm border-l-2 border-accent/70">
                      <p className="text-sm font-semibold text-neutral-light">
                        {user?.username || participant.userId}
                        <span className="text-xs text-neutral-default font-normal ml-1"> (User ID: {participant.userId})</span>
                      </p>
                      <p className="text-xs text-secondary">In-Game Name: <span className="font-medium">{participant.gameName}</span></p>
                      {participant.resultImageUrl ? (
                        <div className="mt-1.5">
                          <p className="text-xs text-neutral-default">Result Submitted: {participant.resultSubmittedDate ? formatDate(participant.resultSubmittedDate) : "Yes"}</p>
                          <a href={participant.resultImageUrl} target="_blank" rel="noopener noreferrer" className="inline-block mt-1 border border-primary-dark p-1 rounded hover:border-secondary transition-colors">
                            <img src={participant.resultImageUrl} alt={`Result for ${user?.username || participant.userId}`} className="w-24 h-16 object-cover rounded-sm"/>
                          </a>
                        </div>
                      ) : (
                        <p className="text-xs text-neutral-dark italic mt-1.5">No result submitted yet.</p>
                      )}
                    </div>
                  );
                })}
              </div>
              )}
            </div>
          )}
           {editingTournament && editingTournament.participants && editingTournament.participants.length === 0 && (
             <div className="mt-6 pt-4 border-t border-primary-light">
                <p className="text-sm text-neutral-dark text-center py-3">No participants have joined this tournament yet.</p>
             </div>
           )}


          <div className="flex justify-end space-x-3 pt-4 border-t border-primary-light mt-6">
            <Button type="button" onClick={() => {setIsModalOpen(false); resetFormAndModal();}} variant="ghost">Cancel</Button>
            <Button type="submit" isLoading={isLoadingData} variant="primary">{editingTournament ? "Save Changes" : "Create Tournament"}</Button>
          </div>
        </form>
      </Modal>
    </PageContainer>
  );
};

const PlusIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" /></svg>;
const EditIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4"><path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" /></svg>;


export default AdminTournamentsPage;