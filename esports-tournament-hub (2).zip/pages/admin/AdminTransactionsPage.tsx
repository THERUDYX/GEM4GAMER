

import React, { useState, useEffect } from 'react';
import { useData } from '../../hooks/useData';
import { Transaction, TransactionStatus, TransactionType, UserBankDetails, AlertMessage } from '../../types';
import PageContainer from '../../components/layout/PageContainer';
import Button from '../../components/ui/Button';
import Card from '../../components/ui/Card';
import { formatCurrency, formatDate } from '../../utils/helpers';
import LoadingSpinner from '../../components/ui/LoadingSpinner';
import Modal from '../../components/ui/Modal';
import Input from '../../components/ui/Input';
import Alert from '../../components/ui/Alert';
import { CURRENCY_SYMBOL } from '../../constants';
// import { useLanguage } from '../../hooks/useLanguage'; // Removed useLanguage

const EmptyStateIcon = () => (
 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-20 h-20 text-primary-light mx-auto mb-4">
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 15.75h3.75m-3.75 3h3.75M12 12.75h3.75" />
 </svg>
);


const AdminTransactionsPage: React.FC = () => {
  const { transactions, updateTransactionStatus, fetchTransactions, isLoadingData } = useData();
  // const { t, language } = useLanguage(); // Removed useLanguage
  const [filter, setFilter] = useState<TransactionStatus | 'all'>(TransactionStatus.PENDING);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [action, setAction] = useState<'approve' | 'decline' | null>(null);
  const [adminNotes, setAdminNotes] = useState('');
  const [alert, setAlert] = useState<AlertMessage | null>(null);

  useEffect(() => {
    fetchTransactions(); // Fetch all transactions
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filterOptions: { value: TransactionStatus | 'all'; label: string }[] = [
    { value: TransactionStatus.PENDING, label: "Pending" },
    { value: TransactionStatus.CONFIRMED, label: "Confirmed" },
    { value: TransactionStatus.DECLINED, label: "Declined" },
    { value: 'all', label: "All" },
  ];

  const filteredTransactions = transactions.filter(tx => {
    if (filter === 'all') return true;
    return tx.status === filter;
  }).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const handleAction = (transaction: Transaction, newAction: 'approve' | 'decline') => {
    setSelectedTransaction(transaction);
    setAction(newAction);
    setAdminNotes(''); 
    setAlert(null);
  };

  const submitAction = async () => {
    if (!selectedTransaction || !action) return;
    setAlert(null);
    try {
      await updateTransactionStatus(selectedTransaction.id, action === 'approve' ? TransactionStatus.CONFIRMED : TransactionStatus.DECLINED, adminNotes);
      setAlert({ id:'txUpdateSuccess', type:'success', message: `Transaction ${action === 'approve' ? 'approved' : 'declined'} successfully.` });
      setSelectedTransaction(null);
      setAction(null);
      fetchTransactions(); 
    } catch (error) {
      console.error("Error updating transaction:", error);
      setAlert({ id:'txUpdateFail', type:'error', message: "Failed to update transaction status."});
    }
  };

  const renderBankDetails = (details?: UserBankDetails) => {
    if (!details) return <p className="text-xs text-neutral-dark">No bank details provided by user.</p>;
    return (
      <div className="text-xs text-neutral-default mt-1 space-y-0.5">
        <p><strong>Account Holder:</strong> {details.accountHolderName}</p>
        <p><strong>Account Number:</strong> {details.accountNumber}</p>
        <p><strong>Bank Name:</strong> {details.bankName}</p>
        <p><strong>IFSC Code:</strong> {details.ifscCode}</p>
      </div>
    );
  };
  
  const currencySymbol = CURRENCY_SYMBOL;

  return (
    <PageContainer title="Manage Transactions">
      {alert && <Alert alert={alert} onDismiss={() => setAlert(null)} />}
      <div className="mb-8 p-3 bg-background-paper rounded-xl shadow-md">
        <div className="flex flex-wrap gap-2">
            {filterOptions.map(opt => (
              <Button
                key={opt.label}
                onClick={() => setFilter(opt.value)}
                variant={filter === opt.value ? 'primary' : 'outline'}
                size="sm"
                className="flex-grow sm:flex-grow-0"
              >
                {opt.label} ({opt.value === 'all' ? transactions.length : transactions.filter(tx => tx.status === opt.value).length})
              </Button>
            ))}
        </div>
      </div>


      {isLoadingData && transactions.length === 0 ? (
        <LoadingSpinner text="Loading transactions..." />
      ) : filteredTransactions.length === 0 ? (
        <div className="text-center text-neutral-default py-16 px-6 bg-background-paper rounded-xl shadow-lg">
           <EmptyStateIcon />
           <p className="text-2xl font-semibold text-neutral-light mt-2">No Transactions Found</p>
           <p className="text-neutral-dark mt-2 mb-6">There are no transactions matching the filter: "{filterOptions.find(f=>f.value === filter)?.label || filter}".</p>
           {filter !== 'all' && 
             <Button onClick={() => setFilter('all')} variant="secondary" size="md">View All Transactions</Button>
           }
         </div>
      ) : (
        <div className="space-y-6">
          {filteredTransactions.map(tx => (
            <Card key={tx.id} className="hover:shadow-secondary/20 transition-all duration-300">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-x-6 gap-y-4 items-start">
                <div className="md:col-span-3 space-y-1.5">
                  <p className="text-sm">
                    <strong className="text-neutral-light">User ID:</strong> <span className="text-accent text-xs font-mono">{tx.userId}</span>
                  </p>
                  <p className="text-lg font-bold">
                    <span className={tx.type === TransactionType.DEPOSIT ? 'text-blue-400' : tx.type === TransactionType.WITHDRAWAL ? 'text-purple-400' : 'text-pink-400' }>{tx.type}</span> 
                    {' - '} 
                    <span className="text-secondary">{formatCurrency(tx.amount, currencySymbol)}</span>
                  </p>
                  <p className="text-xs text-neutral-default">Date: {formatDate(tx.date)}</p>
                  <p className="text-xs text-neutral-default">Status: <span className={`font-semibold px-2 py-0.5 rounded-full border ${
                      tx.status === TransactionStatus.PENDING ? 'text-yellow-400 border-yellow-400/50 bg-yellow-400/10' :
                      tx.status === TransactionStatus.CONFIRMED ? 'text-green-400 border-green-400/50 bg-green-400/10' : 
                      'text-red-400 border-red-400/50 bg-red-400/10'
                    }`}>{tx.status}</span>
                  </p>
                  <p className="text-sm text-neutral-default mt-1">Description: {tx.description}</p>
                  
                  {tx.type === TransactionType.DEPOSIT && tx.utrNumber && (
                    <p className="text-sm text-neutral-default">
                        <strong>UTR/Txn ID:</strong> <span className="font-semibold text-accent">{tx.utrNumber}</span>
                    </p>
                  )}

                  {tx.type === TransactionType.DEPOSIT && tx.paymentScreenshotUrl && (
                    <div className="pt-1">
                      <a 
                        href={tx.paymentScreenshotUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-sm text-accent hover:underline"
                      >
                        View Payment Screenshot
                      </a>
                    </div>
                  )}

                  {tx.type === TransactionType.WITHDRAWAL && tx.userBankDetails && (
                     <div className="pt-2 mt-2 border-t border-primary-light/50">
                        <p className="text-sm font-semibold text-neutral-light mb-1">Withdrawal To:</p>
                        {renderBankDetails(tx.userBankDetails)}
                     </div>
                  )}
                  {tx.adminNotes && <p className="text-sm text-neutral-dark italic mt-1">Admin Note: {tx.adminNotes}</p>}
                </div>
                <div className="md:col-span-1 flex flex-col space-y-2 md:items-end">
                  {tx.status === TransactionStatus.PENDING && (
                    <>
                      <Button onClick={() => handleAction(tx, 'approve')} variant="secondary" size="sm" className="w-full md:w-auto bg-success hover:bg-green-700 text-white" IconLeft={CheckIcon}>Approve</Button>
                      <Button onClick={() => handleAction(tx, 'decline')} variant="danger" size="sm" className="w-full md:w-auto" IconLeft={XIcon}>Decline</Button>
                    </>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal
        isOpen={!!selectedTransaction && !!action}
        onClose={() => { setSelectedTransaction(null); setAction(null); }}
        title={`${action === 'approve' ? "Approve" : "Decline"} Transaction`}
        size="lg"
      >
        {selectedTransaction && (
          <div>
            <p className="mb-4 text-neutral-light">Are you sure you want to {action === 'approve' ? "approve" : "decline"} this {selectedTransaction.type.toLowerCase()} of {formatCurrency(selectedTransaction.amount, currencySymbol)} for User ID: {selectedTransaction.userId}?</p>
            
            {selectedTransaction.type === TransactionType.DEPOSIT && (
              <div className="my-3 p-3 bg-primary-light rounded-lg border border-primary-dark">
                {selectedTransaction.utrNumber && (
                    <p className="text-sm mb-2">
                        <strong>UTR/Txn ID:</strong> <span className="font-semibold text-accent">{selectedTransaction.utrNumber}</span>
                    </p>
                )}
                {selectedTransaction.paymentScreenshotUrl && (
                  <>
                    <p className="text-sm font-semibold text-neutral-light mb-2">Payment Screenshot:</p>
                    <img src={selectedTransaction.paymentScreenshotUrl} alt="Payment Screenshot" className="max-w-full md:max-w-md max-h-60 my-2 rounded-md border-2 border-primary-dark shadow-sm object-contain"/>
                    <a href={selectedTransaction.paymentScreenshotUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-accent hover:underline">View full size</a>
                  </>
                )}
              </div>
            )}
            
            {selectedTransaction.type === TransactionType.WITHDRAWAL && selectedTransaction.userBankDetails && (
                <div className="my-3 p-3 bg-primary-light rounded-lg border border-primary-dark">
                    <p className="text-sm font-semibold text-neutral-light mb-2">Verify Withdrawal Details:</p>
                    {renderBankDetails(selectedTransaction.userBankDetails)}
                </div>
            )}
            <Input
              label="Admin Notes (Optional)"
              name="adminNotes"
              value={adminNotes}
              onChange={(e) => setAdminNotes(e.target.value)}
              placeholder="e.g., Verified payment / Insufficient proof"
              className="mb-6"
              // @ts-ignore
              as="textarea"
              rows={3}
            />
            <div className="flex justify-end space-x-3">
              <Button onClick={() => { setSelectedTransaction(null); setAction(null); }} variant="ghost">Cancel</Button>
              <Button onClick={submitAction} variant={action === 'approve' ? 'primary' : 'danger'} isLoading={isLoadingData}>
                Confirm {action?.charAt(0).toUpperCase() + action?.slice(1)}
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </PageContainer>
  );
};

const CheckIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" /></svg>;
const XIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>;


export default AdminTransactionsPage;