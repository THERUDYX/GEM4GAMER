
import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import PageContainer from '../../components/layout/PageContainer';
import Card from '../../components/ui/Card';
import { ROUTE_OWNER_USERS, ROUTE_ADMIN_DASHBOARD } from '../../constants'; // Added ROUTE_ADMIN_DASHBOARD for quick access

const OwnerDashboardPage: React.FC = () => {
  const { currentUser, isOwner } = useAuth();

  if (!currentUser || !isOwner) {
    return <PageContainer title="Access Denied"><p>You do not have permission to view this page.</p></PageContainer>;
  }

  const UsersIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 19.128a9.38 9.38 0 002.625.372 9.337 9.337 0 004.121-.952 4.125 4.125 0 00-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 018.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0111.964-3.07M12 6.375a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zm8.25 2.25a2.625 2.625 0 11-5.25 0 2.625 2.625 0 015.25 0z" />
    </svg>
  );

  const AdminPanelIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 17.25v1.007a3 3 0 01-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0115 18.257V17.25m6-12V15a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 15V5.25m18 0A2.25 2.25 0 0018.75 3H5.25A2.25 2.25 0 003 5.25m18 0V12a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 12V5.25" />
    </svg>
  );


  return (
    <PageContainer title="Owner Dashboard">
      <p className="mb-6 text-neutral-default">Welcome, Owner! Use this panel for special user management and administrative tasks.</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Link to={ROUTE_OWNER_USERS} className="block">
          <Card className="text-center hover:bg-primary-light transition-colors py-8">
            <UsersIcon className="w-20 h-20 mx-auto mb-4 text-accent" />
            <h2 className="text-2xl font-semibold text-neutral-light">Super User Management</h2>
            <p className="text-sm text-neutral-default mt-1">View and edit all user details, including credentials.</p>
          </Card>
        </Link>

        <Link to={ROUTE_ADMIN_DASHBOARD} className="block">
          <Card className="text-center hover:bg-primary-light transition-colors py-8">
            <AdminPanelIcon className="w-20 h-20 mx-auto mb-4 text-accent" />
            <h2 className="text-2xl font-semibold text-neutral-light">Access Admin Panel</h2>
            <p className="text-sm text-neutral-default mt-1">Perform standard administrative tasks (tournaments, transactions).</p>
          </Card>
        </Link>
      </div>
    </PageContainer>
  );
};

export default OwnerDashboardPage;