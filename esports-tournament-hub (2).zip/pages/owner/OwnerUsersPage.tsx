
import React, { useEffect, useState } from 'react';
import { useData } from '../../hooks/useData';
import PageContainer from '../../components/layout/PageContainer';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import LoadingSpinner from '../../components/ui/LoadingSpinner';
import { formatCurrency } from '../../utils/helpers';
import { User, AlertMessage } from '../../types';
import EditUserModal from '../../components/owner/EditUserModal'; 
import Alert from '../../components/ui/Alert';
import { CURRENCY_SYMBOL } from '../../constants';

const EmptyStateIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-20 h-20 text-primary-light mx-auto mb-4">
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M18.375 12.739l-7.693 7.693a4.5 4.5 0 01-6.364-6.364l7.693-7.693a4.5 4.5 0 016.364 6.364l-1.146 1.147" />
  </svg>
);

const EyeIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

const EyeSlashIcon = () => (
 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
  <path strokeLinecap="round" strokeLinejoin="round" d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.242 4.242L9.88 9.88" />
</svg>
);

const EditPencilIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
      <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />
    </svg>
);


const OwnerUsersPage: React.FC = () => {
  const { allUsers, fetchAllUsers, isLoadingData } = useData();
  const [selectedUserForEdit, setSelectedUserForEdit] = useState<User | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [alertInfo, setAlertInfo] = useState<AlertMessage | null>(null);
  const [showPasswordForUser, setShowPasswordForUser] = useState<Record<string, boolean>>({});

  useEffect(() => {
    fetchAllUsers();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const openEditModal = (user: User) => {
    setSelectedUserForEdit(user);
    setIsEditModalOpen(true);
  };

  const closeEditModal = () => {
    setSelectedUserForEdit(null);
    setIsEditModalOpen(false);
    fetchAllUsers(); 
  };
  
  const toggleShowPassword = (userId: string) => {
    setShowPasswordForUser(prev => ({ ...prev, [userId]: !prev[userId] }));
  };

  if (isLoadingData && allUsers.length === 0) {
    return <PageContainer title="Super User Management"><LoadingSpinner text="Loading users..." /></PageContainer>;
  }

  return (
    <PageContainer title="Super User Management">
      {alertInfo && <Alert alert={alertInfo} onDismiss={() => setAlertInfo(null)} />}
      <div className="mb-4 p-3 bg-red-800/20 border border-red-700 text-red-300 rounded-md text-sm">
        <strong className="font-semibold">Security & Stability Warning:</strong> Editing User IDs or passwords directly is highly risky and can lead to data corruption or security vulnerabilities. This panel is for emergency or demonstration purposes in a mock environment ONLY.
      </div>
      {allUsers.length === 0 && !isLoadingData ? (
        <div className="text-center text-neutral-default py-16 px-6 bg-background-paper rounded-xl shadow-lg">
           <EmptyStateIcon />
           <p className="text-2xl font-semibold text-neutral-light mt-2">No Users Found</p>
           <p className="text-neutral-dark mt-2 mb-6">There are currently no registered users in the system.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {allUsers.map((user: User) => (
            <Card key={user.id} className="hover:shadow-primary-dark/50 transition-all duration-300">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-8 gap-x-6 gap-y-4 items-start">
                <div className="xl:col-span-1">
                  <p className="text-xs text-neutral-default uppercase tracking-wider font-medium">User ID</p>
                  <p className="text-sm text-accent font-mono truncate" title={user.id}>{user.id}</p>
                </div>
                <div className="xl:col-span-1">
                  <p className="text-xs text-neutral-default uppercase tracking-wider font-medium">Username</p>
                  <p className="text-neutral-light font-semibold text-md">{user.username}</p>
                </div>
                <div className="xl:col-span-1">
                  <p className="text-xs text-neutral-default uppercase tracking-wider font-medium">Email</p>
                  <p className="text-neutral-light text-sm truncate" title={user.email}>{user.email}</p>
                </div>
                <div className="xl:col-span-1">
                  <p className="text-xs text-neutral-default uppercase tracking-wider font-medium">Mobile</p>
                  <p className="text-neutral-light text-sm">{user.mobileNumber || 'N/A'}</p>
                </div>
                <div className="xl:col-span-2"> {/* Wider for password */}
                  <p className="text-xs text-neutral-default uppercase tracking-wider font-medium">Password</p>
                  <div className="flex items-center space-x-2">
                    <span className="text-neutral-light text-sm font-mono break-all">
                      {showPasswordForUser[user.id] ? user.password || 'N/A' : '••••••••'}
                    </span>
                    <Button onClick={() => toggleShowPassword(user.id)} variant="ghost" size="sm" className="p-1 flex-shrink-0">
                      {showPasswordForUser[user.id] ? <EyeSlashIcon /> : <EyeIcon />}
                    </Button>
                  </div>
                </div>
                <div className="xl:col-span-1">
                  <p className="text-xs text-neutral-default uppercase tracking-wider font-medium">Role & Balance</p>
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-0.5 text-xs font-semibold rounded-full border ${
                        user.role === 'owner' ? 'border-red-500 text-red-400 bg-red-500/10' :
                        user.role === 'admin' ? 'border-secondary text-secondary bg-secondary/10' : 
                        'border-accent text-accent bg-accent/10'
                    }`}>
                      {user.role}
                    </span>
                    <span className="text-neutral-light font-semibold">{formatCurrency(user.balance, CURRENCY_SYMBOL)}</span>
                  </div>
                </div>
                <div className="xl:col-span-1 text-left sm:text-right flex flex-col sm:items-end gap-2">
                    <Button
                        onClick={() => openEditModal(user)}
                        variant="secondary"
                        size="sm"
                        IconLeft={EditPencilIcon}
                        className="bg-orange-500 hover:bg-orange-600 text-white focus:ring-orange-500 w-full sm:w-auto"
                    >
                        Edit User
                    </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
      {selectedUserForEdit && (
        <EditUserModal
            isOpen={isEditModalOpen}
            onClose={closeEditModal}
            userToEdit={selectedUserForEdit}
        />
      )}
    </PageContainer>
  );
};

export default OwnerUsersPage;