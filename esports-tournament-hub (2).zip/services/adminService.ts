

import { AdminBankDetails } from '../types';
import { dbGetAdminBankDetails, dbSaveAdminBankDetails } from './mockDb';

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const getAdminBankDetails = async (): Promise<AdminBankDetails | null> => {
  await delay(200);
  return dbGetAdminBankDetails();
};

export const updateAdminBankDetails = async (details: Omit<AdminBankDetails, 'id' | 'lastUpdated'>): Promise<AdminBankDetails | null> => {
  await delay(400);
  const currentDetails = dbGetAdminBankDetails();
  if (!currentDetails) return null; // Should not happen if initialized

  const updatedDetails: AdminBankDetails = {
    ...currentDetails,
    accountHolderName: details.accountHolderName,
    accountNumber: details.accountNumber,
    bankName: details.bankName,
    ifscCode: details.ifscCode,
    upiId: details.upiId || undefined,
    qrCodeImageUrl: details.qrCodeImageUrl || undefined, // Handle QR code image
    lastUpdated: new Date().toISOString(),
  };
  dbSaveAdminBankDetails(updatedDetails);
  return updatedDetails;
};