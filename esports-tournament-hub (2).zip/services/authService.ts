
import { User } from '../types';
import { dbGetUsers, dbSaveUsers } from './mockDb';
import { generateId, isValidEmail, isValidPassword } from '../utils/helpers';
import { DEFAULT_ADMIN_EMAIL, DEFAULT_ADMIN_PASSWORD, DEFAULT_OWNER_EMAIL, DEFAULT_OWNER_PASSWORD, LS_AUTH_USER_KEY, LS_TOURNAMENTS_KEY, LS_TRANSACTIONS_KEY } from '../constants';
import { Tournament, Transaction } from '../types'; // Import for ID updates


// Simulate API delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const getAllUsers = (): User[] => {
    const users = dbGetUsers();
    // WARNING: Returning passwords, even to an admin/owner, is a major security risk in real applications.
    // Passwords should be hashed and never stored or displayed in plaintext.
    // This is for mock/demonstration purposes ONLY.
    return users;
};

export const login = async (email: string, password: string): Promise<User | null> => {
  await delay(500);
  const usersFromDb = dbGetUsers(); 
  
  const user = usersFromDb.find(u => u.email.toLowerCase() === email.toLowerCase());

  // Check default admin or owner credentials OR stored password
  if (user) {
    let passwordMatch = false;
    if (user.email === DEFAULT_ADMIN_EMAIL && user.role === 'admin' && password === DEFAULT_ADMIN_PASSWORD) {
        passwordMatch = true;
    } else if (user.email === DEFAULT_OWNER_EMAIL && user.role === 'owner' && password === DEFAULT_OWNER_PASSWORD) {
        passwordMatch = true;
    } else if (user.password === password) { // Direct comparison (insecure, for mock only)
        passwordMatch = true;
    }

    if (passwordMatch) {
        const { password: _, ...userWithoutPassword } = user; 
        return userWithoutPassword;
    }
  }
  
  return null;
};

export const signup = async (username: string, email: string, mobileNumber: string, password: string): Promise<User | null> => {
  await delay(500);
  if (!username || username.trim().length < 3) throw new Error("Username must be at least 3 characters long.");
  if (username.includes(" ")) throw new Error("Username cannot contain spaces.");
  if (!isValidEmail(email)) throw new Error("Invalid email format.");
  if (!mobileNumber || !/^\d{10}$/.test(mobileNumber)) throw new Error("Mobile number must be 10 digits.");
  if (!isValidPassword(password)) throw new Error("Password must be at least 6 characters long.");

  const users = dbGetUsers();
  if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
    throw new Error("User with this email already exists.");
  }
  if (users.find(u => u.username.toLowerCase() === username.toLowerCase())) {
    throw new Error("Username is already taken.");
  }
  if (users.find(u => u.mobileNumber === mobileNumber)) {
    throw new Error("User with this mobile number already exists.");
  }


  const newUser: User = {
    id: generateId(),
    username: username.trim(),
    email: email.toLowerCase(),
    mobileNumber, 
    password, 
    role: 'user',
    balance: 0,
    joinedTournamentIds: [],
  };
  users.push(newUser);
  dbSaveUsers(users);
  
  const { password: _, ...userWithoutPassword } = newUser; 
  return userWithoutPassword;
};

export const logout = async (): Promise<void> => {
  await delay(200);
  return Promise.resolve();
};

export const updateUser = async (userId: string, updates: Partial<User>): Promise<User | null> => {
    await delay(300);
    let users = dbGetUsers();
    const userIndex = users.findIndex(u => u.id === userId);
    if (userIndex === -1) return null;
    
    const { username, password: newPassword, role, id, ...otherUpdates } = updates; 
     if (username && users[userIndex].username !== username && users.some(u => u.username.toLowerCase() === username.toLowerCase() && u.id !== userId)) {
        throw new Error("Username is already taken by another user.");
    }
    
    const originalPassword = users[userIndex].password;
    users[userIndex] = { ...users[userIndex], ...otherUpdates };
    if (username) users[userIndex].username = username;
    // Password and role are NOT updated via this general method
    users[userIndex].password = originalPassword;

    dbSaveUsers(users);
    const { password: _, ...updatedUserWithoutPassword } = users[userIndex];

    const authUserJson = localStorage.getItem(LS_AUTH_USER_KEY);
    if (authUserJson) {
        const authUser: User = JSON.parse(authUserJson);
        if (authUser.id === userId) {
            localStorage.setItem(LS_AUTH_USER_KEY, JSON.stringify(updatedUserWithoutPassword));
        }
    }
    return updatedUserWithoutPassword;
};

export const getUserById = async (userId: string): Promise<User | null> => {
    await delay(100);
    const users = dbGetUsers();
    const user = users.find(u => u.id === userId);
    if (!user) return null;
    const { password: _, ...userWithoutPassword } = user;
    return userWithoutPassword;
};


// Unsafe update function for owner, allowing ID and password changes
export const ownerUpdateUserUnsafe = async (userIdToUpdate: string, updates: Partial<User>): Promise<User | null> => {
  await delay(400);
  let users = dbGetUsers();
  const userIndex = users.findIndex(u => u.id === userIdToUpdate);
  if (userIndex === -1) throw new Error("User not found for update.");

  const oldUserId = users[userIndex].id;
  const newUserId = updates.id || oldUserId;

  // Validate for uniqueness if critical fields are changing
  if (updates.username && users.some(u => u.username.toLowerCase() === updates.username!.toLowerCase() && u.id !== userIdToUpdate)) {
    throw new Error("Username is already taken.");
  }
  if (updates.email && users.some(u => u.email.toLowerCase() === updates.email!.toLowerCase() && u.id !== userIdToUpdate)) {
    throw new Error("Email is already taken.");
  }
  if (updates.mobileNumber && users.some(u => u.mobileNumber === updates.mobileNumber && u.id !== userIdToUpdate)) {
    throw new Error("Mobile number is already taken.");
  }
  if (newUserId !== oldUserId && users.some(u => u.id === newUserId && u.id !== userIdToUpdate)) { // Check if new ID is taken by another user
      throw new Error("New User ID is already taken by another user.");
  }


  // Apply updates directly
  users[userIndex] = { ...users[userIndex], ...updates };
  // Ensure the ID is correctly updated if it was part of 'updates'
  users[userIndex].id = newUserId; 

  // If User ID changed, update it across related data (tournaments, transactions)
  // This is a complex operation and highly prone to issues in real systems.
  if (newUserId !== oldUserId) {
    console.warn(`User ID changed from ${oldUserId} to ${newUserId}. Attempting to update related records. This is risky.`);
    
    // Update transactions
    let transactions = JSON.parse(localStorage.getItem(LS_TRANSACTIONS_KEY) || '[]') as Transaction[];
    transactions.forEach(tx => {
      if (tx.userId === oldUserId) {
        tx.userId = newUserId;
      }
    });
    localStorage.setItem(LS_TRANSACTIONS_KEY, JSON.stringify(transactions));

    // Update tournament participants and joinedTournamentIds in User objects
    let tournaments = JSON.parse(localStorage.getItem(LS_TOURNAMENTS_KEY) || '[]') as Tournament[];
    tournaments.forEach(t => {
      t.participants.forEach(p => {
        if (p.userId === oldUserId) {
          p.userId = newUserId;
        }
      });
    });
    localStorage.setItem(LS_TOURNAMENTS_KEY, JSON.stringify(tournaments));

    // Update joinedTournamentIds in user objects (if any other users have this ID somehow, which shouldn't happen)
    // More importantly, update the current user's joinedTournamentIds if their ID changed
    users.forEach(u => {
        if(u.id === newUserId) { // The user whose ID potentially changed
            u.joinedTournamentIds = u.joinedTournamentIds.map(tid => {
                // This part is tricky if tournament IDs themselves could change, but they don't in this app.
                // If the user was referencing their old ID in some list that is not `joinedTournamentIds`, that would be a separate issue.
                // For `joinedTournamentIds`, the list itself is correct, it's the `User.id` that changed.
                return tid; 
            });
        }
    });
  }

  dbSaveUsers(users);
  const updatedUser = users[userIndex];
  
  // If the updated user is the currently authenticated user, update localStorage too
  const authUserJson = localStorage.getItem(LS_AUTH_USER_KEY);
  if (authUserJson) {
      const authUser: User = JSON.parse(authUserJson);
      // Compare with oldUserId because the authUser.id might be the one that changed
      if (authUser.id === oldUserId) { 
          const { password: _, ...userToStoreInAuth } = updatedUser;
          localStorage.setItem(LS_AUTH_USER_KEY, JSON.stringify(userToStoreInAuth));
      }
  }

  // Return user object without password for safety, even though owner can see it elsewhere
  const { password: _, ...resultUser } = updatedUser;
  return resultUser;
};