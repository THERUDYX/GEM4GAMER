
import { User, Tournament, Transaction, AdminBankDetails } from '../types';
import { LS_USERS_KEY, LS_TOURNAMENTS_KEY, LS_TRANSACTIONS_KEY, LS_ADMIN_BANK_DETAILS_KEY, DEFAULT_ADMIN_EMAIL, DEFAULT_ADMIN_PASSWORD, DEFAULT_OWNER_EMAIL, DEFAULT_OWNER_PASSWORD } from '../constants';
import { generateId } from '../utils/helpers';

// Helper to get item from localStorage
const getItem = <T,>(key: string): T | null => {
  const item = localStorage.getItem(key);
  return item ? JSON.parse(item) as T : null;
};

// Helper to set item in localStorage
const setItem = <T,>(key: string, value: T): void => {
  localStorage.setItem(key, JSON.stringify(value));
};

// Initialize default admin user if not exists
const initializeAdminUser = () => {
  let users = getItem<User[]>(LS_USERS_KEY) || [];
  if (!users.find(u => u.email === DEFAULT_ADMIN_EMAIL)) {
    users.push({
      id: generateId(),
      username: 'admin',
      email: DEFAULT_ADMIN_EMAIL,
      password: DEFAULT_ADMIN_PASSWORD, 
      role: 'admin',
      balance: 0,
      joinedTournamentIds: [],
      mobileNumber: '9999999990', 
    });
    setItem(LS_USERS_KEY, users);
  }
};
initializeAdminUser();

// Initialize default owner user if not exists
const initializeOwnerUser = () => {
  let users = getItem<User[]>(LS_USERS_KEY) || [];
  if (!users.find(u => u.email === DEFAULT_OWNER_EMAIL)) {
    users.push({
      id: generateId(),
      username: 'owner',
      email: DEFAULT_OWNER_EMAIL,
      password: DEFAULT_OWNER_PASSWORD,
      role: 'owner',
      balance: 100000, // Owner gets some starting balance for fun
      joinedTournamentIds: [],
      mobileNumber: '9999999999',
    });
    setItem(LS_USERS_KEY, users);
  }
};
initializeOwnerUser();


// Initialize default admin bank details if not exists
const initializeAdminBankDetails = () => {
  let details = getItem<AdminBankDetails>(LS_ADMIN_BANK_DETAILS_KEY);
  if (!details) {
    details = {
      id: 'main_deposit_details',
      accountHolderName: 'Esports Hub Admin',
      accountNumber: '0000123456789',
      bankName: 'Global Esports Bank',
      ifscCode: 'ESPB0000001',
      upiId: 'admin-esports@upi',
      qrCodeImageUrl: undefined,
      lastUpdated: new Date().toISOString(),
    };
    setItem(LS_ADMIN_BANK_DETAILS_KEY, details);
  }
};
initializeAdminBankDetails();


// User DB Operations
export const dbGetUsers = (): User[] => getItem<User[]>(LS_USERS_KEY) || [];
export const dbSaveUsers = (users: User[]): void => setItem(LS_USERS_KEY, users);

// Tournament DB Operations
export const dbGetTournaments = (): Tournament[] => getItem<Tournament[]>(LS_TOURNAMENTS_KEY) || [];
export const dbSaveTournaments = (tournaments: Tournament[]): void => setItem(LS_TOURNAMENTS_KEY, tournaments);

// Transaction DB Operations
export const dbGetTransactions = (): Transaction[] => getItem<Transaction[]>(LS_TRANSACTIONS_KEY) || [];
export const dbSaveTransactions = (transactions: Transaction[]): void => setItem(LS_TRANSACTIONS_KEY, transactions);

// Admin Bank Details DB Operations
export const dbGetAdminBankDetails = (): AdminBankDetails | null => getItem<AdminBankDetails>(LS_ADMIN_BANK_DETAILS_KEY);
export const dbSaveAdminBankDetails = (details: AdminBankDetails): void => setItem(LS_ADMIN_BANK_DETAILS_KEY, details);