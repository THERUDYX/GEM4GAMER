
import { Tournament, TournamentStatus, TransactionType, TransactionStatus, User, UserParticipation } from '../types';
import { dbGetTournaments, dbSaveTournaments, dbGetUsers, dbSaveUsers } from './mockDb';
import { generateId } from '../utils/helpers';
import { DEFAULT_TOURNAMENT_IMAGE } from '../constants';
import * as transactionService from './transactionService'; // For creating entry fee transaction
import * as authService from './authService';

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const getAllTournaments = async (): Promise<Tournament[]> => {
  await delay(300);
  return dbGetTournaments().sort((a,b) => new Date(b.scheduleDate).getTime() - new Date(a.scheduleDate).getTime());
};

export const getTournamentById = async (id: string): Promise<Tournament | null> => {
  await delay(200);
  const tournaments = dbGetTournaments();
  return tournaments.find(t => t.id === id) || null;
};

export const createTournament = async (data: Omit<Tournament, 'id' | 'status' | 'participants'>): Promise<Tournament | null> => {
  await delay(500);
  const tournaments = dbGetTournaments();
  const newTournament: Tournament = {
    id: generateId(),
    name: data.name,
    game: data.game,
    entryFee: data.entryFee,
    prizePool: data.prizePool,
    scheduleDate: data.scheduleDate,
    imageUrl: data.imageUrl || DEFAULT_TOURNAMENT_IMAGE,
    roomId: data.roomId,
    roomPassword: data.roomPassword,
    status: TournamentStatus.UPCOMING, // Default status for new tournaments
    participants: [], // Initialize with empty participants array
    maxParticipants: data.maxParticipants || 50, // Default if not provided
  };
  tournaments.push(newTournament);
  dbSaveTournaments(tournaments);
  return newTournament;
};

export const updateTournament = async (id: string, updates: Partial<Tournament>): Promise<Tournament | null> => {
  await delay(400);
  let tournaments = dbGetTournaments();
  const index = tournaments.findIndex(t => t.id === id);
  if (index === -1) return null;
  tournaments[index] = { ...tournaments[index], ...updates };
  dbSaveTournaments(tournaments);
  return tournaments[index];
};

export const joinTournament = async (tournamentId: string, userId: string, gameName: string): Promise<boolean> => {
  await delay(600);
  let tournaments = dbGetTournaments();
  let users = dbGetUsers();
  
  const tournament = tournaments.find(t => t.id === tournamentId);
  const user = users.find(u => u.id === userId);

  if (!tournament || !user) throw new Error("Tournament or user not found.");
  if (tournament.status !== TournamentStatus.UPCOMING) throw new Error("Can only join upcoming tournaments.");
  if (user.balance < tournament.entryFee) throw new Error("Insufficient balance.");
  if (tournament.participants.some(p => p.userId === userId)) throw new Error("Already joined this tournament.");
  if (tournament.participants.length >= tournament.maxParticipants) throw new Error("Tournament is full.");
  if (!gameName || gameName.trim() === "") throw new Error("In-game name is required.");


  // Deduct entry fee
  user.balance -= tournament.entryFee;
  if (!user.joinedTournamentIds.includes(tournamentId)) {
    user.joinedTournamentIds.push(tournamentId);
  }
  
  // Add participant with game name
  tournament.participants.push({ userId, gameName });
  
  // Create transaction record for entry fee
  await transactionService.createTransaction({
    userId,
    type: TransactionType.TOURNAMENT_ENTRY,
    amount: tournament.entryFee,
    status: TransactionStatus.CONFIRMED,
    description: `Entry fee for ${tournament.name} (In-game: ${gameName})`,
  });

  dbSaveTournaments(tournaments);
  dbSaveUsers(users);

  // Update user in auth context (important for balance update)
  await authService.updateUser(userId, { balance: user.balance, joinedTournamentIds: user.joinedTournamentIds });
  
  return true;
};

export const submitTournamentResult = async (tournamentId: string, userId: string, resultImageUrl: string): Promise<Tournament | null> => {
  await delay(500);
  let tournaments = dbGetTournaments();
  const tournamentIndex = tournaments.findIndex(t => t.id === tournamentId);
  if (tournamentIndex === -1) {
    throw new Error("Tournament not found.");
  }

  const tournament = tournaments[tournamentIndex];
  if (tournament.status !== TournamentStatus.COMPLETED) {
    throw new Error("Results can only be submitted for completed tournaments.");
  }

  const participantIndex = tournament.participants.findIndex(p => p.userId === userId);
  if (participantIndex === -1) {
    throw new Error("User did not participate in this tournament or participation record not found.");
  }
  
  if (tournament.participants[participantIndex].resultImageUrl) {
    throw new Error("Result has already been submitted for this tournament.");
  }

  tournament.participants[participantIndex].resultImageUrl = resultImageUrl;
  tournament.participants[participantIndex].resultSubmittedDate = new Date().toISOString();
  
  dbSaveTournaments(tournaments);
  return tournament;
};
