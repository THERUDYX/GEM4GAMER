

import { Transaction, TransactionStatus, TransactionType, User, UserBankDetails, AdminBankDetails } from '../types';
import { dbGetTransactions, dbSaveTransactions, dbGetUsers, dbSaveUsers, dbGetAdminBankDetails } from './mockDb';
import { generateId } from '../utils/helpers';
import * as authService from './authService';

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const getAllTransactions = async (): Promise<Transaction[]> => {
  await delay(300);
  return dbGetTransactions().sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const getUserTransactions = async (userId: string): Promise<Transaction[]> => {
  await delay(300);
  const allTransactions = dbGetTransactions();
  return allTransactions.filter(tx => tx.userId === userId).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

// Internal helper for creating transactions
export const createTransaction = async (data: Omit<Transaction, 'id' | 'date'> & { paymentScreenshotUrl?: string, utrNumber?: string }): Promise<Transaction | null> => {
  await delay(200);
  const transactions = dbGetTransactions();
  const newTransaction: Transaction = {
    ...data,
    id: generateId(),
    date: new Date().toISOString(),
    utrNumber: data.utrNumber, // Add UTR number
  };
  transactions.push(newTransaction);
  dbSaveTransactions(transactions);
  return newTransaction;
};

export const requestDeposit = async (userId: string, amount: number, paymentScreenshotUrl: string, utrNumber?: string): Promise<Transaction | null> => {
  await delay(400);
  const users = dbGetUsers();
  const user = users.find(u => u.id === userId);
  if (!user || amount <= 0) return null;

  return createTransaction({
    userId,
    type: TransactionType.DEPOSIT,
    amount,
    status: TransactionStatus.PENDING,
    description: 'User requested deposit',
    paymentScreenshotUrl, 
    utrNumber, // Pass UTR number
  });
};

export const requestWithdrawal = async (userId: string, amount: number, userBankDetails: UserBankDetails): Promise<Transaction | null> => {
  await delay(400);
  const users = dbGetUsers();
  const user = users.find(u => u.id === userId);
  if (!user || amount <= 0 || user.balance < amount) return null;

  const newTransaction = await createTransaction({
    userId,
    type: TransactionType.WITHDRAWAL,
    amount,
    status: TransactionStatus.PENDING,
    description: 'User requested withdrawal',
    userBankDetails,
  });

  return newTransaction;
};

export const updateTransactionStatus = async (
  transactionId: string, 
  status: TransactionStatus, 
  adminNotes?: string
): Promise<Transaction | null> => {
  await delay(500);
  let transactions = dbGetTransactions();
  let users = dbGetUsers();
  const transactionIndex = transactions.findIndex(tx => tx.id === transactionId);

  if (transactionIndex === -1) return null;

  const transaction = transactions[transactionIndex];
  if (transaction.status !== TransactionStatus.PENDING) return transaction; 

  transaction.status = status;
  transaction.adminNotes = adminNotes;

  if (status === TransactionStatus.CONFIRMED) {
    const user = users.find(u => u.id === transaction.userId);
    if (user) {
      if (transaction.type === TransactionType.DEPOSIT) {
        user.balance += transaction.amount;
      } else if (transaction.type === TransactionType.WITHDRAWAL) {
        if (user.balance < transaction.amount) {
          transaction.status = TransactionStatus.DECLINED;
          transaction.adminNotes = "Insufficient balance at time of confirmation.";
        } else {
          user.balance -= transaction.amount;
        }
      }
      dbSaveUsers(users);
      await authService.updateUser(user.id, { balance: user.balance });
    } else {
       transaction.status = TransactionStatus.DECLINED;
       transaction.adminNotes = "User account not found during confirmation.";
    }
  }

  transactions[transactionIndex] = transaction;
  dbSaveTransactions(transactions);
  return transaction;
};

export const grantBonusCredit = async (userId: string, amount: number, adminNotes?: string): Promise<Transaction | null> => {
  await delay(400);
  let users = dbGetUsers();
  const user = users.find(u => u.id === userId);

  if (!user || amount <= 0) {
    console.error("User not found or invalid amount for bonus credit.");
    return null;
  }

  // Update user's balance
  user.balance += amount;
  dbSaveUsers(users); 

  // Create a confirmed transaction for the bonus credit
  const bonusTransaction = await createTransaction({
    userId,
    type: TransactionType.BONUS_CREDIT,
    amount,
    status: TransactionStatus.CONFIRMED,
    description: 'Bonus credit granted by admin.',
    adminNotes: adminNotes || 'Admin granted bonus.',
  });

  // Ensure AuthContext's currentUser (if it's this user) gets updated balance by calling updateUser
  await authService.updateUser(user.id, { balance: user.balance });

  return bonusTransaction;
};