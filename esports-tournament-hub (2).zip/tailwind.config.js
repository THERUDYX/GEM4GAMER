// Tailwind CSS is loaded via CDN and configured directly in the <script> tag in index.html for runtime.
// This file contains the equivalent configuration for completeness and
// potential use if you were to build Tailwind CSS as part of a build process.
module.exports = {
  content: [
    "./index.html",
    "./**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
       colors: {
        primary: {
          DEFAULT: '#003B46',
          light: '#005260',
          dark: '#002A30',
        },
        secondary: {
          DEFAULT: '#00BCD4',
          light: '#33D5E8',
          dark: '#00AABF',
        },
        accent: {
          DEFAULT: '#FFC107',
          light: '#FFD54F',
          dark: '#FFA000',
        },
        neutral: {
          light: '#F5F5F5',
          DEFAULT: '#E0E0E0',
          dark: '#CCCCCC',
          darker: '#333333',
        },
        background: {
          DEFAULT: '#001014',
          paper: '#001F26',
        },
        success: '#34D399',
        error: '#F87171',
        warning: '#FBBF24',
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      animation: {
        'slide-in-fade': 'slideInFade 0.5s ease-out forwards',
        'fade-out': 'fadeOut 0.5s ease-out forwards',
        'modal-in': 'modalIn 0.3s ease-out forwards',
        'modal-out': 'modalOut 0.3s ease-in forwards',
      },
      keyframes: {
        slideInFade: {
          '0%': { opacity: '0', transform: 'translateY(-20px) translateX(20px)' }, /* Adjusted for top-right */
          '100%': { opacity: '1', transform: 'translateY(0) translateX(0)' },
        },
        fadeOut: {
          '0%': { opacity: '1', transform: 'translateY(0) translateX(0)' },
          '100%': { opacity: '0', transform: 'translateY(-20px) translateX(20px)' },
        },
        modalIn: {
          '0%': { opacity: '0', transform: 'scale(0.95) translateY(10px)' },
          '100%': { opacity: '1', transform: 'scale(1) translateY(0)' },
        },
        modalOut: {
          '0%': { opacity: '1', transform: 'scale(1) translateY(0)' },
          '100%': { opacity: '0', transform: 'scale(0.95) translateY(10px)' },
        }
      }
    },
  },
  plugins: [],
}