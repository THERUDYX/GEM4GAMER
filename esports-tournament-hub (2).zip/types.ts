

export interface User {
  id: string;
  username: string;
  email: string;
  password?: string; // Present during signup, not stored directly or fetched
  role: 'user' | 'admin' | 'owner'; // Added 'owner'
  balance: number; // in INR
  joinedTournamentIds: string[]; // Keep this as string[] for simplicity, details in Tournament.participants
  bankDetails?: UserBankDetails;
  mobileNumber?: string;
}

export interface UserBankDetails {
  accountHolderName: string;
  accountNumber: string;
  bankName: string;
  ifscCode: string;
}

export interface AdminBankDetails {
  id: string; // Typically a single record, e.g., 'main_deposit_details'
  accountHolderName: string;
  accountNumber: string;
  bankName: string;
  ifscCode: string;
  upiId?: string;
  qrCodeImageUrl?: string; // Optional: Base64 data URI for QR code image
  lastUpdated: string; // ISO date string
}

export enum TournamentStatus {
  UPCOMING = 'Upcoming',
  ONGOING = 'Ongoing',
  COMPLETED = 'Completed',
}

export interface UserParticipation {
  userId: string;
  gameName: string; // User's in-game name for this tournament
  resultImageUrl?: string; // Base64 data URI of the uploaded result image
  resultSubmittedDate?: string; // ISO date string
}

export interface Tournament {
  id: string;
  name: string;
  game: string;
  entryFee: number; // in INR
  prizePool: number; // in INR
  scheduleDate: string; // ISO date string
  imageUrl: string; // Can be a URL or base64 data URI
  roomId?: string;
  roomPassword?: string;
  status: TournamentStatus;
  participants: UserParticipation[]; // Updated from string[] to UserParticipation[]
  maxParticipants: number; // Maximum number of participants allowed
}

export enum TransactionType {
  DEPOSIT = 'Deposit',
  WITHDRAWAL = 'Withdrawal',
  TOURNAMENT_ENTRY = 'Tournament Entry',
  BONUS_CREDIT = 'Bonus Credit',
}

export enum TransactionStatus {
  PENDING = 'Pending',
  CONFIRMED = 'Confirmed',
  DECLINED = 'Declined',
}

export interface Transaction {
  id: string;
  userId: string;
  type: TransactionType;
  amount: number; // in INR
  status: TransactionStatus;
  date: string; // ISO date string
  description: string;
  userBankDetails?: UserBankDetails; // For withdrawals
  adminNotes?: string; // Notes from admin on approval/decline
  paymentScreenshotUrl?: string; // Base64 data URI for deposit screenshots
  utrNumber?: string;
}

export interface AuthContextType {
  currentUser: User | null;
  isAdmin: boolean;
  isOwner: boolean; // Added isOwner
  loading: boolean;
  login: (email: string, password: string) => Promise<User | null>;
  signup: (username: string, email: string, mobileNumber: string, password: string) => Promise<User | null>;
  logout: () => Promise<void>;
  refreshCurrentUser: () => Promise<void>;
}

export interface DataContextType {
  tournaments: Tournament[];
  transactions: Transaction[];
  adminBankDetails: AdminBankDetails | null;
  allUsers: User[]; // For admin/owner to view users
  fetchTournaments: () => Promise<void>;
  createTournament: (tournamentData: Omit<Tournament, 'id' | 'status' | 'participants'>) => Promise<Tournament | null>;
  updateTournament: (tournamentId: string, updates: Partial<Tournament>) => Promise<Tournament | null>;
  joinTournament: (tournamentId: string, userId: string, gameName: string) => Promise<boolean>;
  submitTournamentResult: (tournamentId: string, userId: string, resultImageUrl: string) => Promise<Tournament | null>;
  fetchTransactions: (userId?: string) => Promise<void>;
  requestDeposit: (userId: string, amount: number, paymentScreenshotUrl: string, utrNumber?: string) => Promise<Transaction | null>;
  requestWithdrawal: (userId: string, amount: number, bankDetails: UserBankDetails) => Promise<Transaction | null>;
  updateTransactionStatus: (transactionId: string, status: TransactionStatus, adminNotes?: string) => Promise<Transaction | null>;
  grantBonusCredit: (userId: string, amount: number, adminNotes?: string) => Promise<Transaction | null>;
  fetchAdminBankDetails: () => Promise<void>;
  updateAdminBankDetails: (details: Omit<AdminBankDetails, 'id' | 'lastUpdated'>) => Promise<AdminBankDetails | null>;
  fetchAllUsers: () => Promise<void>;
  ownerUpdateUser: (userId: string, updates: Partial<User>) => Promise<User | null>; // New for owner
  isLoadingData: boolean;
}

export interface AlertMessage {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
}

export interface TimeRemaining {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  totalSeconds: number;
}