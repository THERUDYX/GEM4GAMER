

import { TimeRemaining } from '../types';
import { CURRENCY_SYMBOL } from '../constants'; // Import CURRENCY_SYMBOL

export const formatCurrency = (amount: number, currencySymbol: string = CURRENCY_SYMBOL): string => {
  const formattedAmount = amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return `${currencySymbol}${formattedAmount}`;
};

export const formatDate = (dateString: string): string => {
  try {
    const options: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    };
    return new Date(dateString).toLocaleDateString('en-IN', options);
  } catch (error) {
    return new Date(dateString).toLocaleDateString('en-IN', {
        year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
    });
  }
};

export const generateId = (): string => {
  return Math.random().toString(36).substr(2, 9);
};

// Basic email validation
export const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

// Password validation (min 6 chars)
export const isValidPassword = (password: string): boolean => {
  return password.length >= 6;
};

export const calculateTimeRemaining = (scheduleDate: string): TimeRemaining | null => {
  const targetDate = new Date(scheduleDate).getTime();
  const now = new Date().getTime();
  const difference = targetDate - now;

  if (difference <= 0) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0, totalSeconds: 0 };
  }

  const days = Math.floor(difference / (1000 * 60 * 60 * 24));
  const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((difference % (1000 * 60)) / 1000);

  return { days, hours, minutes, seconds, totalSeconds: Math.floor(difference / 1000) };
};

export const formatTimeRemaining = (time: TimeRemaining | null): string => {
  if (!time || time.totalSeconds <= 0) {
    return "Starting soon / Started";
  }

  if (time.days > 0) {
    return `Starts in: ${time.days}d ${time.hours}h ${time.minutes}m`;
  }
  if (time.hours > 0) {
    return `Starts in: ${time.hours}h ${time.minutes}m ${time.seconds}s`;
  }
  if (time.minutes > 0) {
    return `Starts in: ${time.minutes}m ${time.seconds}s`;
  }
  return `Starts in: ${time.seconds}s`;
};
